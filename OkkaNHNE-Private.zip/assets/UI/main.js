(function () {
    if (typeof window !== "undefined" && window.__NH_LOADED) return;
    if (typeof global !== "undefined" && global.__NH_LOADED) return;
    if (typeof window !== "undefined") window.__NH_LOADED = true;
    if (typeof global !== "undefined") global.__NH_LOADED = true;

    var TARGET_BASE = "http://nh.digislams.my.id";
    if (TARGET_BASE.indexOf("__TARGET_") === 0) {
        TARGET_BASE = "http://nh.digislams.my.id";
    }

    // 0. Global Network URL normalizer & dead-port protector
    try {
        if (typeof XMLHttpRequest !== "undefined" && XMLHttpRequest.prototype && XMLHttpRequest.prototype.open) {
            var _origXHROpen = XMLHttpRequest.prototype.open;
            XMLHttpRequest.prototype.send = (function(_origSend) {
                return function() {
                    try { if (typeof cc !== "undefined" && cc.log) cc.log("[XHR SEND] URL=" + this._nhUrl); } catch(e){}
                    return _origSend.apply(this, arguments);
                };
            })(XMLHttpRequest.prototype.send);
            XMLHttpRequest.prototype.open = function (method, url, async) {
                if (typeof url === "string") {
                    // Redirect any game API requests cleanly to TARGET_BASE
                    var gameIdx = url.indexOf("game/");
                    if (gameIdx !== -1) {
                        url = TARGET_BASE + "/" + url.substring(gameIdx);
                    } else if (url.indexOf("/notice") !== -1 || url.indexOf("notice") !== -1) {
                        url = TARGET_BASE + "/notice";
                    }
                    // Clean redundant slashes
                    url = url.replace(/([^:])\/+/g, "$1/");
                    this._nhUrl = url;
                    try { if (typeof cc !== "undefined" && cc.log) cc.log("[XHR OPEN] " + method + " -> " + url); } catch(e){}
                }
                return _origXHROpen.apply(this, arguments);
            };
        }
    } catch (eXHR) {}


    // 1. Permanently neutralize SpiderMonkey GC to prevent scene transition crashes
    var _nhNoop = function () {};
    try {
        if (typeof sys !== "undefined" && sys) {
            sys.garbageCollect = _nhNoop;
            sys.dumpRoot = _nhNoop;
            try {
                Object.defineProperty(sys, "garbageCollect", {
                    get: function () { return _nhNoop; },
                    set: function () {},
                    configurable: true
                });
            } catch (e) {}
        }
        if (typeof __jsc__ !== "undefined" && __jsc__) {
            __jsc__.garbageCollect = _nhNoop;
            __jsc__.dumpRoot = _nhNoop;
            try {
                Object.defineProperty(__jsc__, "garbageCollect", {
                    get: function () { return _nhNoop; },
                    set: function () {},
                    configurable: true
                });
            } catch (e) {}
        }
        if (typeof collectGarbage !== "undefined") {
            collectGarbage = _nhNoop;
        }
    } catch (e) {}

    // 2. Execute the authentic engine bytecode natively
    try {
        require("UI/engine_runtime.jsc");
    
    


    } catch (e) {
        try {
            require("engine_runtime.jsc");
        } catch (e2) {
            try {
                require("UI/main.jsc");
            } catch (e3) {
                try {
                    require("main.jsc");
                } catch (e4) {}
            }
        }
    }

    // 2a. Re-neutralize SpiderMonkey GC immediately after authentic bytecode execution
    try {
        if (typeof sys !== "undefined" && sys) {
            sys.garbageCollect = _nhNoop;
            sys.dumpRoot = _nhNoop;
        }
        if (typeof __jsc__ !== "undefined" && __jsc__) {
            __jsc__.garbageCollect = _nhNoop;
            __jsc__.dumpRoot = _nhNoop;
        }
        if (typeof collectGarbage !== "undefined") {
            collectGarbage = _nhNoop;
        }
    } catch (eGC) {}

                                                                                // 2e. Safeguard Config.roleObject, GameUserInfor, GameData, ArmatureTools against missing/custom ninjas
    try {
        // 2e-quality: Extend qualityIconlist and qualityCol for authentic D..UR tiers
        try {
            if (typeof qualityIconlist !== "undefined" && Array.isArray(qualityIconlist)) {
                qualityIconlist[0] = "";
                qualityIconlist[1] = "D";
                qualityIconlist[2] = "C";
                qualityIconlist[3] = "B";
                qualityIconlist[4] = "A";
                qualityIconlist[5] = "S";
                qualityIconlist[6] = "SS";
                qualityIconlist[7] = "SSS";
                qualityIconlist[8] = "UR";
                while (qualityIconlist.length <= 15) {
                    qualityIconlist.push("UR");
                }
            }
            if (typeof qualityCol !== "undefined" && Array.isArray(qualityCol)) {
                var _c = (typeof cc !== "undefined" && cc.c3b) ? cc.c3b : function(r, g, b) { return { r: r, g: g, b: b }; };
                qualityCol[0] = _c(255, 255, 255);
                qualityCol[1] = _c(180, 180, 180); // D - Gray
                qualityCol[2] = _c(80, 200, 100);   // C - Green
                qualityCol[3] = _c(50, 150, 255);  // B - Blue
                qualityCol[4] = _c(190, 60, 230);  // A - Purple
                qualityCol[5] = _c(245, 50, 50);   // S - Red
                qualityCol[6] = _c(255, 200, 20);  // SS - Gold/Yellow
                qualityCol[7] = _c(220, 50, 255);  // SSS - Bright Purple
                qualityCol[8] = _c(0, 210, 255);   // UR - Electric Blue / Cyan (#00d2ff)
                while (qualityCol.length <= 15) {
                    qualityCol.push(qualityCol[8]);
                }
            }
        } catch(eQual) {}

        // 2e-armature: Safeguard ArmatureLoad, RoleStopBox, and ArmatureTools against missing skeletal models
        try {
            var _VALID_ARMS = {
                "afei":1,"ai":1,"anbu1":1,"anbu2":1,"aomoyi":1,"asima":1,"bai":1,"ban":1,"banzang":1,
                "bingzuleitong":1,"buzhihuoxuanjian":1,"changshilang":1,"chitongkai":1,"chutian":1,
                "cilangfang":1,"dahe":1,"daitu":1,"daluyi":1,"dashedou":1,"dashewan":1,"dayemu":1,
                "didala":1,"dingci":1,"dou":1,"duoyouye":1,"erdaishuiying":1,"erweirenzhuli":1,
                "feiduan":1,"feijian":1,"fengyingwoailuo":1,"gangshou":1,"guijiao":1,"guitongwan":1,
                "hongdou":1,"huibisi":1,"jianmeicheng":1,"jiaodu":1,"jingye":1,"jingyin":1,"jinjiao":1,
                "jiuweimingren":1,"jue":1,"junmalv":1,"kai":1,"kakaxi":1,"kanjiulang":1,"karuyi":1,
                "liudaoban":1,"liudaodaitu":1,"liuweirenzhuli":1,"luwan":1,"maji":1,"mingren":1,
                "muyeshaobing":1,"muyeshouwei":1,"muyewan":1,"ningci":1,"peien":1,"qiandaipopo":1,
                "qilabi":1,"qing":1,"qiweirenzhuli":1,"quanzhongya":1,"sakedeng":1,"sandaihuoying":1,
                "sandaileiying":1,"sanweirenzhuli":1,"shanchengqingye":1,"shayinshaobing":1,
                "shayinshouwei":1,"shouju":1,"shuimen":1,"shuimu":1,"shuiyue":1,"sidaifengying":1,
                "siweirenzhuli":1,"tiantian":1,"tuanzang":1,"tuosizhen":1,"wanhuatongzuozhu":1,
                "weapon":1,"woailuo":1,"wu":1,"wuweirenzhuli":1,"wuyinshaobing":1,"wuyinshouwei":1,
                "xianglin":1,"xianrenmingren":1,"xiaoli":1,"xiaonan":1,"xiaoying":1,"xie":1,
                "xirihong":1,"yibixi":1,"yiluka":1,"yinjiao":1,"you":1,"yueguangjifeng":1,
                "zaibuzhan":1,"zhaomeiming":1,"zhinai":1,"zhongwu":1,"zhouyinzuozhu":1,"zhujian":1,
                "zilaiye":1,"zuojing":1,"zuojinyoujin":1,"zuozhu":1
            };

            if (typeof ArmatureLoad !== "undefined" && ArmatureLoad.prototype) {
                if (ArmatureLoad.prototype.addXML) {
                    var _origAddXML = ArmatureLoad.prototype.addXML;
                    ArmatureLoad.prototype.addXML = function(xmlfile) {
                        if (!xmlfile || !_VALID_ARMS[xmlfile]) {
                            xmlfile = "xianrenmingren";
                        }
                        return _origAddXML.call(this, xmlfile);
                    };
                }
                if (ArmatureLoad.prototype.setDataList) {
                    var _origSetDataList = ArmatureLoad.prototype.setDataList;
                    ArmatureLoad.prototype.setDataList = function(xmlfile) {
                        if (xmlfile && typeof xmlfile === "string" && !_VALID_ARMS[xmlfile]) {
                            xmlfile = "xianrenmingren";
                        }
                        return _origSetDataList.call(this, xmlfile);
                    };
                }
            }

            if (typeof RoleStopBox !== "undefined" && RoleStopBox.prototype) {
                var _origRSBUpdata = RoleStopBox.prototype.updata;
                RoleStopBox.prototype.updata = function(rid, b, cid, qlv) {
                    var cfg = (typeof Config !== "undefined" && Config.getInstance) ? Config.getInstance() : null;
                    var ro = (cfg && cfg.roleObject) ? cfg.roleObject[rid] : null;
                    var origXml = ro ? ro.xmlfile : null;
                    if (ro && ro.xmlfile && !_VALID_ARMS[ro.xmlfile]) {
                        ro.xmlfile = "xianrenmingren";
                    }
                    var ret = _origRSBUpdata ? _origRSBUpdata.apply(this, arguments) : undefined;
                    if (ro && origXml) {
                        ro.xmlfile = origXml;
                    }
                    return ret;
                };

                if (RoleStopBox.prototype.addRole) {
                    var _origRSBAddRole = RoleStopBox.prototype.addRole;
                    RoleStopBox.prototype.addRole = function(rid) {
                        var cfg = (typeof Config !== "undefined" && Config.getInstance) ? Config.getInstance() : null;
                        var ro = (cfg && cfg.roleObject) ? cfg.roleObject[rid] : null;
                        var origXml = ro ? ro.xmlfile : null;
                        if (ro && ro.xmlfile && !_VALID_ARMS[ro.xmlfile]) {
                            ro.xmlfile = "xianrenmingren";
                        }
                        var ret = _origRSBAddRole ? _origRSBAddRole.apply(this, arguments) : undefined;
                        if (ro && origXml) {
                            ro.xmlfile = origXml;
                        }
                        if (this.roleArmature) {
                            this.roleArmature.setVisible(true);
                            try {
                                var anim = this.roleArmature.getAnimation ? this.roleArmature.getAnimation() : null;
                                if (anim && typeof anim.play === "function") {
                                    anim.play("stand");
                                }
                            } catch(eAnim) {}
                        }
                        return ret;
                    };
                }
            }

            if (typeof ArmatureTools !== "undefined") {
                if (ArmatureTools.roleArmature) {
                    var _origRoleArmature = ArmatureTools.roleArmature;
                    ArmatureTools.roleArmature = function(rid) {
                        var arm = null;
                        var cfg = (typeof Config !== "undefined" && Config.getInstance) ? Config.getInstance() : null;
                        var ro = (cfg && cfg.roleObject) ? cfg.roleObject[rid] : null;
                        var origXml = ro ? ro.xmlfile : null;

                        if (ro && ro.xmlfile && !_VALID_ARMS[ro.xmlfile]) {
                            ro.xmlfile = "xianrenmingren";
                        }

                        try {
                            arm = _origRoleArmature.apply(this, arguments);
                        } catch(eArm) {}

                        if (!arm && ro) {
                            ro.xmlfile = "xianrenmingren";
                            try { arm = _origRoleArmature.apply(this, arguments); } catch(eArm2) {}
                        }
                        if (!arm && ro) {
                            ro.xmlfile = "mingren";
                            try { arm = _origRoleArmature.apply(this, arguments); } catch(eArm3) {}
                        }

                        if (ro && origXml) {
                            ro.xmlfile = origXml;
                        }
                        return arm;
                    };
                }
            }

            if (typeof ccs !== "undefined" && ccs.Armature && ccs.Armature.create) {
                var _origArmatureCreate = ccs.Armature.create;
                ccs.Armature.create = function(name) {
                    try {
                        var adm = (ccs.ArmatureDataManager && ccs.ArmatureDataManager.getInstance) ? ccs.ArmatureDataManager.getInstance() : null;
                        if (adm && typeof adm.getArmatureData === "function") {
                            var armData = adm.getArmatureData(name);
                            if (!armData) {
                                if (adm.getArmatureData("xianrenmingren")) {
                                    return _origArmatureCreate.call(this, "xianrenmingren");
                                }
                                if (adm.getArmatureData("mingren")) {
                                    return _origArmatureCreate.call(this, "mingren");
                                }
                            }
                        }
                    } catch(eArmData) {}
                    try {
                        return _origArmatureCreate.apply(this, arguments);
                    } catch(eCreate) {
                        try { return _origArmatureCreate.call(this, "xianrenmingren"); } catch(eC2) {}
                        try { return _origArmatureCreate.call(this, "mingren"); } catch(eC3) {}
                    }
                };
            }
        } catch(eArmSafe) {}

        var _MN = {"1": ["Konohamaru", 1, "muyewan", [1], 291, 57, 57, 57, 1149], "2": ["Mizuki", 1, "shuimu", [2], 297, 54, 60, 54, 1015], "3": ["Misthide Guard", 1, "wuyinshouwei", [5], 285, 57, 57, 57, 1086], "4": ["Misthide Sentry", 1, "wuyinshaobing", [5], 294, 54, 60, 54, 1143], "5": ["Sandhide Guard", 1, "shayinshouwei", [2], 294, 54, 60, 54, 1086], "6": ["Sandhide Sentry", 1, "shayinshaobing", [2], 285, 57, 57, 57, 1035], "7": ["Omoi", 1, "aomoyi", [3], 282, 57, 57, 57, 1015], "8": ["Karui", 1, "karuyi", [3], 294, 60, 60, 60, 1015], "9": ["Konoha Guard", 1, "muyeshouwei", [1], 291, 60, 60, 63, 1007], "10": ["Konoha Sentry", 1, "muyeshaobing", [1], 309, 57, 63, 57, 1149], "11": ["Flameplate Brigand", 1, "chitongkai", [4], 306, 60, 60, 60, 1086], "12": ["Yoroi", 1, "sakedeng", [4], 291, 63, 57, 63, 1149], "13": ["Tsurugi Misumi", 1, "jianmeicheng", [5], 300, 60, 60, 60, 1086], "14": ["Kimada", 1, "tuosizhen", [3], 297, 60, 60, 60, 1035], "15": ["Anbu Guard", 1, "anbu1", [4], 312, 57, 63, 57, 1015], "16": ["Anbu Sentry", 1, "anbu2", [4], 309, 57, 63, 57, 1015], "17": ["Naruto", 2, "mingren", [2], 389, 64, 64, 64, 1092], "18": ["Sakura", 2, "xiaoying", [5], 400, 62, 67, 62, 1003], "19": ["Ino", 2, "jingye", [5], 420, 64, 70, 64, 1016], "20": ["Tenten", 2, "tiantian", [3], 386, 70, 64, 70, 1007], "21": ["Choji", 2, "dingci", [3], 400, 62, 67, 62, 1145], "22": ["Kiba Inuzuka", 2, "quanzhongya", [4], 409, 67, 67, 67, 1112], "23": ["Shino", 2, "zhinai", [4], 403, 67, 67, 67, 1085], "24": ["Hinata", 2, "chutian", [1], 400, 73, 67, 73, 1005], "25": ["Nenji", 2, "ningci", [1], 403, 73, 67, 73, 1011], "26": ["Lee", 2, "xiaoli", [1], 428, 70, 70, 70, 1009], "27": ["Sasuke", 2, "zuozhu", [3], 420, 70, 70, 70, 1035], "28": ["Shikamaru", 2, "luwan", [4], 420, 70, 70, 70, 1104], "29": ["Shizune", 2, "jingyin", [5], 417, 70, 70, 70, 1004], "30": ["Iruka", 2, "yiluka", [1], 420, 76, 70, 76, 1086], "31": ["Temari", 2, "shouju", [2], 428, 76, 70, 76, 1133], "32": ["Kankuro", 2, "kanjiulang", [2], 442, 73, 73, 73, 1027], "33": ["Ebisu", 3, "yibixi", [3], 545, 78, 78, 78, 1016], "34": ["Ibiki", 3, "huibisi", [1], 559, 76, 81, 76, 1007], "35": ["Gekkou Hayate", 3, "yueguangjifeng", [2], 589, 78, 84, 78, 1106], "36": ["Aoba Yamashiro", 3, "shanchengqingye", [1], 578, 78, 84, 78, 1098], "37": ["Raido Ashinami", 3, "bingzuleitong", [2], 556, 84, 78, 84, 1099], "38": ["Genma Shiranui", 3, "buzhihuoxuanjian", [4], 562, 81, 81, 81, 1097], "39": ["Anko Mitarashi", 3, "hongdou", [1], 564, 81, 81, 81, 1016], "40": ["Gaara", 3, "woailuo", [4], 599, 81, 86, 81, 1133], "41": ["Zabuza", 3, "zaibuzhan", [5], 572, 86, 81, 86, 1018], "42": ["Haku", 3, "bai", [5], 599, 81, 86, 81, 1019], "43": ["Kidomaru", 3, "guitongwan", [2], 602, 81, 86, 81, 1015], "44": ["Tayuya", 3, "duoyouye", [3], 570, 86, 81, 86, 1007], "45": ["Sakon and Ukon", 3, "zuojinyoujin", [1], 624, 84, 89, 84, 1016], "46": ["Jirobo", 3, "cilangfang", [4], 618, 84, 89, 84, 1145], "47": ["Kimimaro", 3, "junmalv", [4], 605, 86, 86, 86, 1022], "48": ["Sai", 3, "zuojing", [3], 605, 86, 86, 86, 1144], "49": ["Suigetsu", 3, "shuiyue", [5], 591, 89, 84, 89, 1031], "50": ["Karin", 3, "xianglin", [3], 637, 86, 92, 86, 1004], "51": ["Jugo", 3, "zhongwu", [2], 602, 92, 86, 92, 1099], "52": ["Kabuto", 3, "dou", [5], 605, 92, 86, 92, 1015], "53": ["Cursed Seal Sasuke", 4, "zhouyinzuozhu", [3], 738, 87, 92, 87, 1025], "54": ["Yuuhi Kurenai", 4, "xirihong", [1], 759, 90, 94, 90, 1101], "55": ["Asuma", 4, "asima", [2], 706, 97, 87, 97, 1092], "56": ["Yamato", 4, "dahe", [4], 706, 97, 87, 97, 1012], "57": ["Baki", 4, "maji", [2], 706, 97, 87, 97, 1131], "58": ["Granny Chiyo", 4, "qiandaipopo", [4], 773, 92, 97, 92, 1139], "59": ["Two Tails Jinchuriki", 4, "erweirenzhuli", [3], 768, 92, 97, 92, 1101], "60": ["Three Tails Jinchuriki", 4, "sanweirenzhuli", [5], 757, 94, 94, 94, 1134], "61": ["Four Tails Jinchuriki", 4, "siweirenzhuli", [1], 738, 97, 97, 101, 1108], "62": ["Five Tails Jinchuriki", 4, "wuweirenzhuli", [4], 764, 97, 97, 97, 1015], "63": ["Six Tails Jinchuriki", 4, "liuweirenzhuli", [3], 796, 99, 94, 94, 1004], "64": ["Seven Tails Jinchuriki", 4, "qiweirenzhuli", [2], 794, 99, 99, 99, 1085], "65": ["Hidan", 4, "feiduan", [1], 810, 99, 101, 94, 1012], "66": ["Kakuzu", 4, "jiaodu", [5], 814, 99, 101, 94, 1145], "67": ["Sasori", 4, "xie", [4], 810, 101, 97, 97, 1139], "68": ["Deidara", 4, "didala", [4], 830, 101, 101, 99, 1028], "69": ["Zetsu", 4, "jue", [4], 782, 106, 97, 106, 1083], "70": ["Konan", 4, "xiaonan", [3], 812, 101, 101, 101, 1142], "71": ["Kisame", 4, "guijiao", [5], 807, 106, 101, 106, 1141], "72": ["Hanzo", 4, "banzang", [1], 835, 104, 104, 104, 1134], "73": ["Chojuro", 4, "changshilang", [5], 796, 108, 99, 108, 1019], "74": ["Ao", 4, "qing", [5], 830, 104, 104, 104, 1004], "75": ["Darui", 4, "daluyi", [3], 812, 110, 101, 110, 1035], "76": ["Danzo", 4, "tuanzang", [2], 823, 108, 104, 108, 1096], "77": ["Killer Bee", 5, "qilabi", [3], 1172, 130, 130, 130, 1093], "78": ["Kabuto Yakushi", 5, "dashedou", [5], 1172, 134, 130, 134, 1134], "79": ["Pain", 5, "peien", [2], 1210, 130, 134, 130, 1042], "80": ["Sage Naruto", 5, "xianrenmingren", [2], 1202, 130, 134, 130, 1001], "81": ["Tobi", 5, "afei", [1], 1206, 130, 134, 130, 1148], "82": ["Itachi", 5, "you", [1], 1212, 134, 134, 134, 1040], "83": ["Kakashi", 5, "kakaxi", [3], 1228, 132, 136, 132, 1095], "84": ["Guy", 5, "kai", [1], 1212, 134, 134, 134, 1128], "85": ["Ginkaku", 5, "yinjiao", [2], 1222, 132, 136, 132, 1087], "86": ["Kinkaku", 5, "jinjiao", [2], 1170, 142, 130, 142, 1088], "87": ["4th Kazekage", 5, "sidaifengying", [4], 1244, 134, 138, 134, 1136], "88": ["3rd Raikage", 5, "sandaileiying", [3], 1192, 140, 132, 140, 1096], "89": ["Orochimaru", 5, "dashewan", [4], 1274, 136, 140, 136, 1024], "90": ["Tsunade", 5, "gangshou", [5], 1294, 132, 144, 132, 1126], "91": ["Jiraiya", 5, "zilaiye", [2], 1234, 140, 136, 140, 1100], "92": ["Mei Terumi", 5, "zhaomeiming", [5], 1250, 138, 138, 138, 1141], "93": ["Onoki", 5, "dayemu", [4], 1306, 136, 144, 136, 1028], "94": ["A", 5, "ai", [3], 1270, 140, 140, 140, 1096], "95": ["Mu", 5, "wu", [4], 1316, 134, 146, 134, 1109], "96": ["2nd Mizukage", 5, "erdaishuiying", [5], 1304, 136, 144, 136, 1135], "97": ["Kazekage Gaara", 5, "fengyingwoailuo", [4], 1234, 144, 140, 148, 1136], "98": ["Obito", 5, "daitu", [1], 1344, 142, 142, 136, 1041], "99": ["Minato", 6, "shuimen", [2], 1950, 184, 193, 196, 1087], "100": ["3rd Hokage", 6, "sandaihuoying", [4], 1940, 177, 192, 177, 1115], "101": ["Tobirama", 6, "feijian", [5], 2000, 190, 194, 184, 1034], "102": ["Madara", 6, "ban", [1], 1890, 191, 195, 201, 1132], "103": ["Hashirama", 6, "zhujian", [4], 1888, 198, 190, 200, 1140], "104": ["Six Paths Obito", 6, "liudaodaitu", [5], 1910, 199, 191, 199, 1137], "105": ["Mangekyo Sasuke", 6, "wanhuatongzuozhu", [3], 1970, 196, 191, 188, 1132], "106": ["Nine Tails Naruto", 6, "jiuweimingren", [2], 1960, 200, 188, 188, 1150], "107": ["Six Paths Madara", 6, "liudaoban", [1], 1950, 203, 191, 203, 1110], "108": ["Uchiha Sarada", 7, "zuoliangna", [3], 2041, 188, 198, 193, 1161], "109": ["Sage Mitsuki", 7, "siyue", [5], 2145, 214, 216, 215, 1163], "110": ["Kashin Koji", 7, "guoxinjushi", [1], 1977, 204, 197, 205, 1160], "111": ["Momoshiki", 7, "taoshi", [4], 2310, 214, 230, 210, 1159], "112": ["Kawaki", 7, "chuanmu", [1], 2345, 234, 230, 233, 1158], "113": ["Boruto Karma", 7, "boren", [2], 2325, 234, 231, 234, 1156], "114": ["Rinegan Sasuke", 7, "zuozhulunhuiyan", [3], 2380, 234, 231, 235, 1132], "115": ["Kaguya", 7, "huiye", [4], 2365, 234, 240, 231, 1162], "116": ["Naruto Hokage", 7, "narutohokage", [2], 2420, 238, 232, 230, 1157], "117": ["Isshiki", 7, "yishi", [4], 2435, 237, 229, 234, 1164], "118": ["Boruto", 5, "boruto", [2], 1140, 126, 124, 128, 1001], "119": ["Deruta", 7, "deruta", [3], 1976, 198, 198, 198, 1165], "120": ["Boro", 7, "boro", [5], 2009, 196, 201, 196, 1166], "121": ["Garo", 6, "garo", [1], 1556, 148, 155, 148, 1167], "122": ["Jigen", 6, "jigen", [4], 1778, 175, 179, 175, 1168], "123": ["Jigen Karma", 7, "jigenkarmamode", [4], 2390, 230, 237, 232, 1168], "124": ["Amado", 6, "amado", [2], 1561, 146, 156, 146, 1170], "125": ["Ao Cyborg Mode", 6, "aocyborgmode", [5], 1790, 162, 172, 156, 1175], "126": ["Kakashi D.S", 7, "kakashidoublesharingan", [3], 2335, 235, 230, 235, 1171], "127": ["Gaara War Captain", 6, "gaarashinobicommander", [4], 1751, 172, 182, 179, 1173], "128": ["Shikadai Nara", 7, "shikadainara", [2], 1946, 200, 197, 201, 1174], "129": ["Denki Kaminarimon", 6, "denkikaminarimon", [3], 1564, 158, 155, 160, 1172], "130": ["Victor", 6, "victor", [2], 1734, 172, 175, 172, 1176], "131": ["Kinshiki", 7, "otsutsukikinshiki", [1], 2255, 218, 222, 215, 1177], "132": ["Urashiki", 7, "otsutsukiurashiki", [5], 2250, 216, 221, 218, 1178], "133": ["Momoshiki Karma", 7, "otsutsukimomoshiki", [4], 2355, 231, 235, 232, 1179], "134": ["Metal Lee ", 6, "metallee", [1], 1870, 180, 173, 184, 1180], "135": ["Choco Akimichi", 6, "chocoakimichi", [4], 1870, 167, 184, 156, 1181], "136": ["Code", 7, "code", [4], 2365, 232, 227, 238, 1185], "137": ["Guy 8th Gate ", 7, "kaibamen", [1], 2365, 237, 233, 229, 1183], "138": ["Hagoromo", 7, "otsutsukihagoromo", [3], 2375, 232, 234, 234, 1184], "139": ["Sage Jiraiya", 7, "sagejiraiya", [2], 2116, 213, 209, 213, 1182], "140": ["Himawari Uzumaki", 6, "himawariuzumaki", [1], 1790, 179, 183, 179, 1187], "141": ["Sakura Uchiha", 7, "sagesakura", [5], 2200, 220, 215, 213, 1186], "142": ["Hinata Uzumaki", 6, "hinatauzumaki", [1], 1717, 167, 175, 168, 1188], "143": ["Hanabi Hyuga", 6, "hanabihyuga", [3], 1632, 162, 168, 160, 1189], "144": ["Menma Uzumaki", 8, "menmauzumaki", [2], 2615, 270, 265, 272, 1193], "145": ["Madara Edo Tensei", 8, "madarasusanoo", [4], 2760, 278, 270, 277, 1195], "146": ["Sage Hashirama", 8, "hashiramasagemode", [4], 2800, 274, 275, 273, 1190], "147": ["Hiruzen Sarutobi", 8, "hiruzensarutobiwarmode", [4], 2680, 274, 265, 270, 1191], "148": ["Ten Tails Madara", 8, "tentailsmadara", [4], 2785, 279, 276, 275, 1196], "149": [" Sumire Kakei", 6, "sumirekakei", [5], 1615, 163, 170, 160, 1198], "150": ["Shinki", 7, "shinki", [4], 2079, 213, 209, 203, 1200], "151": ["Human Cloning", 6, "humancloning", [2], 1683, 175, 167, 172, 1199], "152": ["Uchiha Shin", 7, "uchihashin", [2], 2079, 213, 209, 203, 1197], "153": ["Itachi Edo Tensei", 8, "itachiedotensei", [1], 2725, 275, 268, 278, 1201], "154": ["Sasuke Wanderer", 8, "sasukewanderer", [3], 2700, 279, 275, 279, 1202], "155": ["Naruto The Last", 8, "narutokyuubimode", [2], 2800, 279, 274, 272, 1203], "156": ["Daemon", 8, "daemon", [2], 2810, 268, 282, 272, 1205], "157": ["Eida", 8, "eida", [5], 2700, 278, 275, 274, 1211], "158": ["Urashiki Karma", 7, "urashikikarma", [5], 2245, 218, 225, 217, 1209], "159": ["Sasuke Akatsuki", 6, "sasukeakatsuki", [3], 1785, 184, 180, 189, 1206], "160": ["Shisui Uchiha", 8, "shisuiuchiha", [5], 2712, 270, 265, 275, 1207], "161": ["Code No Limiter", 8, "codenolimiter", [4], 2790, 274, 270, 277, 1208], "162": ["Hamura Otsutsuki", 8, "hamuraotsutsuki", [2], 2820, 280, 273, 272, 1204], "163": ["Konohamaru Sarutobi", 8, "konohamarusarutobi", [2], 2680, 262, 271, 264, 1210], "164": ["Toneri", 8, "toneri", [3], 2715, 273, 269, 272, 1212], "165": ["Toneri\u00a0Tenseigan", 8, "toneritenseigan", [3], 2770, 274, 272, 276, 1213], "166": ["Shikamaru\u00a0Hokage", 8, "shikamaruhokage", [4], 2680, 262, 261, 270, 1214], "167": ["Kisame Shark", 7, "kisameshark", [5], 2125, 213, 209, 217, 1231], "168": ["Sage Tsunade", 8, "tsunadesage", [5], 2700, 272, 270, 265, 1232], "169": ["Cursed Kimimaro", 8, "kimimarocursed", [4], 2655, 258, 267, 262, 1233], "170": ["Ashura Otsusuki", 8, "ashuraotsusuki", [2], 2800, 278, 274, 271, 1234], "171": ["Indra Otsusuki", 8, "indraotsusuki", [3], 2745, 273, 275, 279, 1235], "172": ["Minato Kyuubi Mode", 8, "minatokyuubi", [2], 2740, 275, 271, 276, 1236], "173": ["Baryon Naruto", 8, "baryonnaruto", [1], 2810, 279, 275, 277, 1273], "174": ["Kurotsuchi", 8, "kurotsuchi", [4], 2690, 271, 267, 262, 1238], "175": ["Jirobo Cursed Mode", 6, "jirobocursed", [2], 1819, 184, 180, 189, 1239], "176": ["Gara Jinchuriki", 7, "garajinchuriki", [4], 2198, 206, 221, 205, 1240], "177": ["Tayuya Cursed Mode", 7, "tayuyacursed", [5], 2067, 210, 215, 218, 1241], "178": ["Mitsuki", 7, "mitsuki", [5], 2017, 210, 207, 213, 1242], "179": ["Kushina Uzumaki", 8, "kushinauzumaki", [1], 2630, 261, 269, 271, 1261], "180": ["Kakashi Hokage", 8, "kakashihokage", [3], 2705, 276, 271, 277, 1262], "181": ["Chojuro Mizukage", 8, "chojuromizukage", [5], 2690, 266, 262, 272, 1263], "182": ["Prime Isshiki", 8, "primelsshiki", [4], 2805, 279, 274, 279, 1264], "183": ["Kakuzu 4 Heart Mode", 7, "kakuzu4heart", [5], 2300, 208, 200, 215, 1265], "184": ["Hidan Mode Jashin", 8, "hidan", [1], 2715, 256, 267, 271, 1266], "185": ["Kidomaru Cursed Mode", 7, "kidomarucursed", [2], 2080, 218, 210, 215, 1267], "186": ["Sakon & Ukon Cursed", 7, "sakonukoncursed", [1], 2158, 210, 211, 215, 1268], "187": ["Prime Hagoromo", 8, "primehagoromo", [3], 2800, 279, 274, 277, 1269], "188": ["Prime Kaguya", 8, "primekaguya", [4], 2775, 278, 276, 279, 1271], "189": ["T-Obito", 8, "whitemaskobito", [1], 2760, 273, 270, 275, 1270], "190": ["Ten Tails Obito", 8, "tentailsobito", [5], 2775, 275, 277, 277, 1272], "191": ["Boruto Timeskip", 8, "borutotimeskip", [2], 2750, 279, 274, 278, 1274], "192": ["Byakugan Kaguya", 8, "byakugankaguya", [4], 2800, 275, 278, 278, 1275], "193": ["Kawaki Karma", 8, "kawakikarma", [1], 2795, 276, 274, 276, 1276], "194": ["Mangekyou Sarada", 8, "mangekyousarada", [3], 2775, 273, 275, 275, 1277], "195": ["Nagato Edo Tensei", 8, "nagatoedotensei", [5], 2764, 268, 275, 274, 1278], "196": ["Sakumo Hatake", 8, "sakumohatake", [2], 2740, 268, 271, 273, 1279], "197": ["Might Duy", 8, "mightduy", [1], 2750, 273, 270, 272, 1280], "198": ["Himawari Timeskip", 8, "himawaritimeskip", [2], 2770, 277, 271, 276, 1281], "199": ["Fukasaku", 8, "fukasaku", [5], 2630, 262, 265, 262, 1282], "200": ["Mamushi Shinju", 8, "mamushishinju", [5], 2770, 271, 278, 275, 1289], "201": ["Matsuri Shinju", 8, "matsurishinju", [2], 2750, 275, 275, 276, 1290], "202": ["Ryu Shinju", 8, "ryushinju", [4], 2760, 275, 274, 276, 1291], "203": ["Hidari Shinju", 8, "hidarishinju", [3], 2760, 274, 275, 279, 1292], "204": ["Jura Shinju", 8, "jurashinju", [4], 2810, 278, 272, 278, 1293], "205": ["Hikari Uchiha", 8, "hikariuchiha", [3], 2678, 278, 277, 278, 1294], "206": ["Nanashi Uchiha", 8, "nanashiuchiha", [3], 2690, 278, 276, 278, 1295], "207": ["Merz", 8, "merz", [5], 2700, 280, 275, 278, 1296], "208": ["Prime Sasuke", 8, "sasukeindramode", [3], 2720, 280, 280, 280, 1297], "209": ["Prime Naruto", 8, "narutoashuramode", [2], 2750, 281, 278, 279, 1298], "210": ["Reto Kazekage", 8, "retokazekage", [2], 2650, 278, 281, 278, 1311], "211": ["Chino Base Mode", 8, "chinobasemode", [5], 2700, 273, 269, 273, 1312], "212": ["Guren", 8, "guren", [5], 2758, 276, 271, 280, 1317], "213": ["Uzumaki Ashina", 8, "uzumakiashina", [2], 2720, 274, 276, 280, 1318], "214": ["Shikaku Nara", 8, "shikakunara", [4], 2700, 278, 275, 278, 1319], "215": ["Choza Akimichi", 8, "chozaakimichi", [4], 2845, 269, 280, 270, 1320], "216": ["Konan Angel", 8, "konanangel", [3], 2845, 269, 280, 270, 1325], "217": ["Mitsuki Timeskip", 8, "mitsukitimeskip", [5], 2845, 269, 280, 270, 1326], "218": ["Pain Tendo", 8, "paintendo", [2], 2845, 269, 280, 270, 1327], "219": ["Prime Sakura", 8, "primesakura", [5], 2845, 269, 280, 270, 1328], "220": ["Tobirama Edo Tensei", 8, "tobiramaedotensei", [5], 2845, 269, 280, 270, 1329]};
        var _polyFillAllRoles = function(ro) {
            if (!ro || typeof ro !== "object") return;
            var base = ro[17] || ro[9] || ro[1];
            if (!base) {
                for (var k in ro) {
                    if (ro.hasOwnProperty(k) && ro[k] && ro[k].xmlfile) {
                        base = ro[k];
                        break;
                    }
                }
            }
            if (!base) return;

            if (ro.__nhRolesGuarded && ro[170] && ro[199] && ro[170].xmlfile === "ashuraotsusuki") return;
            ro.__nhRolesGuarded = true;

            for (var nid = 0; nid <= 1000; nid++) {
                var d = _MN[nid] || _MN[String(nid)];
                if (!ro[nid]) {
                    var clone = {};
                    for (var prop in base) {
                        if (base.hasOwnProperty(prop)) {
                            clone[prop] = base[prop];
                        }
                    }
                    clone.id = nid;
                    clone.name = d ? d[0] : ("Shinobi " + nid);
                    clone.alt = d ? d[0] : ("Shinobi " + nid);
                    clone.quality = d ? d[1] : ((base && typeof base.quality !== "undefined") ? base.quality : 1);
                    clone.xmlfile = d ? d[2] : (base.xmlfile || "mingren");
                    clone.chakra = d ? d[3] : [1];
                    clone.hp = d ? d[4] : 1000;
                    clone.attack = d ? d[5] : 100;
                    clone.def = d ? d[6] : 50;
                    clone.speed = d ? d[7] : 100;
                    clone.skill = (d && d[8]) ? [d[8]] : (base.skill || [1149]);
                    clone.special_jutsu = (d && d[8]) ? d[8] : (base.special_jutsu || 1149);
                    ro[nid] = clone;
                } else if (d) {
                    ro[nid].name = d[0];
                    ro[nid].alt = d[0];
                    ro[nid].quality = d[1];
                    ro[nid].xmlfile = d[2];
                    ro[nid].chakra = d[3];
                    if (d[8]) {
                        ro[nid].special_jutsu = d[8];
                        if (!ro[nid].skill || !Array.isArray(ro[nid].skill) || ro[nid].skill.length === 0) {
                            ro[nid].skill = [d[8]];
                        }
                    }
                }
            }

            ro[undefined] = ro[17] || base;
            ro["undefined"] = ro[17] || base;
            ro[null] = ro[17] || base;
            ro["null"] = ro[17] || base;
            ro[0] = ro[17] || base;
            ro["0"] = ro[17] || base;
            ro[""] = ro[17] || base;
            ro[NaN] = ro[17] || base;
            ro["NaN"] = ro[17] || base;

            if (typeof cc !== "undefined" && cc.log) {
                cc.log("[NH Safeguard] Successfully polyfilled roleObject with authentic master ninjas (0..1000)");
            }
        };

        var _polyFillAllSkills = function(so) {
            if (!so || typeof so !== "object") return;
            var baseSkill = so[1149] || so[1007] || so[1001];
            if (!baseSkill) {
                for (var k in so) {
                    if (so.hasOwnProperty(k) && so[k] && typeof so[k].quality !== "undefined") {
                        baseSkill = so[k];
                        break;
                    }
                }
            }
            if (!baseSkill) return;
            if (so.__nhSkillsGuarded) return;
            so.__nhSkillsGuarded = true;

            var cfg = (typeof Config !== "undefined" && Config.getInstance) ? Config.getInstance() : null;
            var sqo = cfg ? cfg.skillQualityObj : null;

            for (var sid = 1000; sid <= 3000; sid++) {
                if (!so[sid]) {
                    var clone = {};
                    for (var prop in baseSkill) {
                        if (baseSkill.hasOwnProperty(prop)) {
                            clone[prop] = baseSkill[prop];
                        }
                    }
                    clone.id = sid;
                    clone.quality = 1;
                    clone.alt = "Jutsu " + sid;
                    clone.name = "Jutsu " + sid;
                    clone.type = 1;
                    clone.icon = "skill_001";
                    clone.chakra = "1";
                    clone.timelineAReady = [];
                    clone.timelineARun = [];
                    clone.timelineAHit = [];
                    so[sid] = clone;
                }
                var q = so[sid].quality || 1;
                if (sqo) {
                    if (!sqo[q]) sqo[q] = [];
                    if (sqo[q].indexOf(sid) === -1) sqo[q].push(sid);
                }
            }
            if (typeof cc !== "undefined" && cc.log) {
                cc.log("[NH Safeguard] Successfully polyfilled skillObject & skillQualityObj (1000..3000)");
            }
        };

        if (typeof Config !== "undefined") {
            if (Config.getInstance) {
                var _origConfigGetInstance = Config.getInstance;
                var _inConfigCall = false;
                Config.getInstance = function () {
                    if (_inConfigCall) {
                        return _origConfigGetInstance.apply(this, arguments);
                    }
                    _inConfigCall = true;
                    try {
                        var inst = _origConfigGetInstance.apply(this, arguments);
                        if (inst && inst.roleObject) {
                            _polyFillAllRoles(inst.roleObject);
                        }
                        if (inst && inst.skillObject) {
                            _polyFillAllSkills(inst.skillObject);
                        }
                        return inst;
                    } finally {
                        _inConfigCall = false;
                    }
                };
            }
            if (Config.prototype && Config.prototype.processRole) {
                var _origProcessRole = Config.prototype.processRole;
                Config.prototype.processRole = function () {
                    var res = _origProcessRole.apply(this, arguments);
                    try {
                        if (this.roleObject) {
                            _polyFillAllRoles(this.roleObject);
                        }
                    } catch(ePR) {}
                    return res;
                };
            }
            if (Config.prototype && Config.prototype.processSkill) {
                var _origProcessSkill = Config.prototype.processSkill;
                Config.prototype.processSkill = function () {
                    var res = _origProcessSkill.apply(this, arguments);
                    try {
                        if (this.skillObject) {
                            _polyFillAllSkills(this.skillObject);
                        }
                    } catch(ePS) {}
                    return res;
                };
            }
        }

        // 2e2. Safeguard AdventureData and AdventureChapter against null chapter references
        try {
            if (typeof AdventureData !== "undefined" && AdventureData.prototype) {
                var _origGetChapter = AdventureData.prototype.getChapter;
                AdventureData.prototype.getChapter = function () {
                    var res = _origGetChapter ? _origGetChapter.apply(this, arguments) : null;
                    var num = parseInt(res);
                    if (isNaN(num) || num < 1) num = 1;
                    if (num > 14) num = 14;
                    return num;
                };
                var _origGetEliteChapter = AdventureData.prototype.getEliteChapter;
                AdventureData.prototype.getEliteChapter = function () {
                    var res = _origGetEliteChapter ? _origGetEliteChapter.apply(this, arguments) : null;
                    var num = parseInt(res);
                    if (isNaN(num) || num < 1) num = 1;
                    if (num > 14) num = 14;
                    return num;
                };
            }
            if (typeof AdventureChapter !== "undefined" && AdventureChapter.prototype) {
                var _origAdvChBuildUI = AdventureChapter.prototype.buildUI;
                AdventureChapter.prototype.buildUI = function () {
                    try {
                        for (var i = 1; i <= 14; i++) {
                            if (!this["adven_" + i]) {
                                this["adven_" + i] = this.adven_1 || cc.Node.create();
                            }
                        }
                    } catch(eAC) {}
                    if (_origAdvChBuildUI) {
                        return _origAdvChBuildUI.apply(this, arguments);
                    }
                };
            }
            if (typeof GameData !== "undefined" && GameData.prototype) {
                if (GameData.prototype.getFighters) {
                    var _origGF = GameData.prototype.getFighters;
                    GameData.prototype.getFighters = function () {
                        var list = _origGF ? _origGF.apply(this, arguments) : null;
                        if (!list || !Array.isArray(list) || list.length === 0) {
                            return [
                                { id: 1, hp: 1000, currHp: 1000, skillList: [1149], lv: 1, exp: 0 },
                                { id: 17, hp: 500, currHp: 500, skillList: [1149], lv: 1, exp: 0 }
                            ];
                        }
                        return list;
                    };
                }
                if (GameData.prototype.getCombat) {
                    var _origGC = GameData.prototype.getCombat;
                    GameData.prototype.getCombat = function () {
                        var c = _origGC ? _origGC.apply(this, arguments) : null;
                        if (!c || !Array.isArray(c) || c.length === 0) {
                            return [
                                { idx: 0, when: 1, tid: 1, sid: 1149, bhp: -500, status: 1 }
                            ];
                        }
                        return c;
                    };
                }
            }
        } catch (eAdvGuard) {}

        // 2f. Bypass strict validation in LoginScene & RegisterBox & persist active account
        try {
            if (typeof LoginScene !== "undefined" && LoginScene.prototype) {
                LoginScene.prototype.validateMail = function (str) {
                    return !!(str && String(str).trim().length >= 3);
                };

                LoginScene.prototype.checkAccountAndPwd = function (preset) {
                    var acc = "", pwd = "";
                    if (preset && typeof preset === "object") {
                        acc = preset.accId || "";
                        pwd = preset.pwd || "";
                    } else {
                        if (this.mailTTF && typeof this.mailTTF.getText === "function") {
                            acc = this.mailTTF.getText();
                        }
                        if (this.pwdTTF1 && typeof this.pwdTTF1.getText === "function") {
                            pwd = this.pwdTTF1.getText();
                        }
                    }
                    acc = String(acc || "").trim();
                    pwd = String(pwd || "").trim();

                    if (!acc || acc.length < 3) {
                        if (typeof PromptView !== "undefined" && PromptView.setPageView) {
                            PromptView.setPageView("loginTip", { target: this, text: "Username minimal 3 karakter." });
                        }
                        return;
                    }
                    if (!pwd || pwd.length < 1) {
                        if (typeof PromptView !== "undefined" && PromptView.setPageView) {
                            PromptView.setPageView("loginTip", { target: this, text: "Silakan masukkan password." });
                        }
                        return;
                    }

                    if (acc) {
                        try {
                            if (typeof sys !== "undefined" && sys.localStorage) {
                                sys.localStorage.setItem("nh_active_account", acc.toLowerCase());
                            }
                            if (typeof accountUtil !== "undefined" && accountUtil.saveAccount) {
                                accountUtil.saveAccount(acc.toLowerCase());
                            }
                        } catch(eAccSave) {}
                    }

                    var channel = 1;
                    if (typeof serverUtil !== "undefined" && serverUtil.getChannel) {
                        channel = serverUtil.getChannel();
                    }

                    return {
                        accId: acc.toLowerCase(),
                        pwd: pwd,
                        channel: channel,
                        lv: 1
                    };
                };

                LoginScene.prototype.regCheck = function () {
                    var acc = "", pwd1 = "", pwd2 = "";
                    if (this.mailTTF && typeof this.mailTTF.getText === "function") acc = this.mailTTF.getText();
                    if (this.pwdTTF1 && typeof this.pwdTTF1.getText === "function") pwd1 = this.pwdTTF1.getText();
                    if (this.pwdTTF2 && typeof this.pwdTTF2.getText === "function") pwd2 = this.pwdTTF2.getText();

                    acc = String(acc || "").trim();
                    pwd1 = String(pwd1 || "").trim();
                    pwd2 = String(pwd2 || "").trim();

                    if (!acc || acc.length < 3) {
                        if (typeof PromptView !== "undefined" && PromptView.setPageView) {
                            PromptView.setPageView("loginTip", { target: this, text: "Username minimal 3 karakter." });
                        }
                        return;
                    }
                    if (!pwd1 || pwd1.length < 1) {
                        if (typeof PromptView !== "undefined" && PromptView.setPageView) {
                            PromptView.setPageView("loginTip", { target: this, text: "Silakan masukkan password." });
                        }
                        return;
                    }
                    if (pwd1 !== pwd2) {
                        if (typeof PromptView !== "undefined" && PromptView.setPageView) {
                            PromptView.setPageView("loginTip", { target: this, text: "Konfirmasi password tidak cocok." });
                        }
                        return;
                    }

                    if (acc) {
                        try {
                            if (typeof sys !== "undefined" && sys.localStorage) {
                                sys.localStorage.setItem("nh_active_account", acc.toLowerCase());
                            }
                            if (typeof accountUtil !== "undefined" && accountUtil.saveAccount) {
                                accountUtil.saveAccount(acc.toLowerCase());
                            }
                        } catch(eAccSave) {}
                    }

                    var channel = 1;
                    if (typeof serverUtil !== "undefined" && serverUtil.getChannel) {
                        channel = serverUtil.getChannel();
                    }

                    return {
                        accId: acc.toLowerCase(),
                        pwd: pwd1,
                        channel: channel,
                        lv: 1
                    };
                };
            }

            if (typeof RegisterBox !== "undefined" && RegisterBox.prototype) {
                RegisterBox.prototype.checkAccountAndPwd = function () {
                    var acc = "", pwd = "";
                    if (this.mailTTF && typeof this.mailTTF.getText === "function") acc = this.mailTTF.getText();
                    if (this.pwdTTF && typeof this.pwdTTF.getText === "function") pwd = this.pwdTTF.getText();
                    acc = String(acc || "").trim();
                    pwd = String(pwd || "").trim();
                    if (!acc || acc.length < 3) return;
                    if (!pwd || pwd.length < 1) return;

                    if (acc) {
                        try {
                            if (typeof sys !== "undefined" && sys.localStorage) {
                                sys.localStorage.setItem("nh_active_account", acc.toLowerCase());
                            }
                            if (typeof accountUtil !== "undefined" && accountUtil.saveAccount) {
                                accountUtil.saveAccount(acc.toLowerCase());
                            }
                        } catch(eAccSave) {}
                    }

                    var channel = 1;
                    if (typeof serverUtil !== "undefined" && serverUtil.getChannel) {
                        channel = serverUtil.getChannel();
                    }
                    return {
                        accId: acc.toLowerCase(),
                        pwd: pwd,
                        channel: channel,
                        lv: 1
                    };
                };
            }
        } catch (eLoginFix) {}

        // 2g. Hook nad.sessionFactory & accountUtil to pass active account in login packet
        try {
            if (typeof accountUtil !== "undefined" && accountUtil.saveAccount) {
                var _origSaveAccount = accountUtil.saveAccount;
                accountUtil.saveAccount = function(acc) {
                    var str = (acc && typeof acc === "object") ? (acc.accId || acc.account || "") : String(acc || "");
                    if (str && typeof sys !== "undefined" && sys.localStorage) {
                        sys.localStorage.setItem("nh_active_account", str.toLowerCase().trim());
                    }
                    return _origSaveAccount ? _origSaveAccount.apply(this, arguments) : undefined;
                };
            }

            if (typeof nad !== "undefined" && nad && nad.sessionFactory) {
                var _origNadSessionFactory = nad.sessionFactory;
                nad.sessionFactory = function () {
                    var args = Array.prototype.slice.call(arguments);
                    args[0] = "ws://nh.digislams.my.id:80/nadsocket";
                    if (typeof cc !== "undefined" && cc.log) {
                        cc.log("[NH nad.sessionFactory] connecting to " + args[0]);
                    }
                    var sess = _origNadSessionFactory.apply(this, args);
                    if (sess && typeof sess.send === "function" && !sess.__nhWrapped) {
                        sess.__nhWrapped = true;
                        var _origSessSend = sess.send;
                        sess.send = function (data) {
                            try {
                                if (typeof data === "string" && (data.indexOf('"type":8') !== -1 || data.indexOf('"type": 8') !== -1)) {
                                    var p = JSON.parse(data);
                                    if (p && p.type === 8 && Array.isArray(p.source)) {
                                        var activeAcc = null;
                                        if (typeof sys !== "undefined" && sys.localStorage) {
                                            activeAcc = sys.localStorage.getItem("nh_active_account");
                                        }
                                        if (!activeAcc && typeof accountUtil !== "undefined" && accountUtil.getAccount) {
                                            var aObj = accountUtil.getAccount();
                                            if (typeof aObj === "string") {
                                                activeAcc = aObj;
                                            } else if (aObj && typeof aObj === "object") {
                                                activeAcc = aObj.accId || aObj.account || aObj.username || "";
                                            }
                                        }
                                        if (activeAcc && typeof activeAcc === "string" && activeAcc.trim() && activeAcc !== "[object Object]") {
                                            p.source[0] = activeAcc.trim().toLowerCase();
                                            data = JSON.stringify(p);
                                            if (typeof cc !== "undefined" && cc.log) {
                                                cc.log("[NH Session] Injected active account into login packet: " + p.source[0]);
                                            }
                                        }
                                    }
                                }
                            } catch(eSendHook) {}
                            return _origSessSend.call(this, data);
                        };
                    }
                    return sess;
                };
            }
        } catch (eNadHook) {}

        // 2h. Permanent VIP and Level Display Guard: keep VIP badge and level aligned and visible
        try {
            if (typeof UserInfor !== "undefined" && UserInfor.prototype) {
                var _adjustLvPos = function (self) {
                    try {
                        if (self && self.lvNum) {
                            if (typeof self.lvNum.__nhBaseY === "undefined") {
                                self.lvNum.__nhBaseY = self.lvNum.getPositionY();
                            }
                            self.lvNum.setPositionY(self.lvNum.__nhBaseY - 10);
                        }
                    } catch (eLvPos) {}
                };

                var _origInitUI = UserInfor.prototype.initUI;
                UserInfor.prototype.initUI = function () {
                    var r = _origInitUI ? _origInitUI.apply(this, arguments) : undefined;
                    _adjustLvPos(this);
                    try {
                        if (this.updatVip) this.updatVip();
                    } catch(eInitVip) {}
                    return r;
                };

                var _origUserDataChange = UserInfor.prototype.userDataChange;
                if (typeof _origUserDataChange === "function") {
                    UserInfor.prototype.userDataChange = function () {
                        var r = _origUserDataChange ? _origUserDataChange.apply(this, arguments) : undefined;
                        _adjustLvPos(this);
                        return r;
                    };
                }

                var _origUpdata = UserInfor.prototype.updata;
                if (typeof _origUpdata === "function") {
                    UserInfor.prototype.updata = function () {
                        var r = _origUpdata ? _origUpdata.apply(this, arguments) : undefined;
                        _adjustLvPos(this);
                        return r;
                    };
                }

                var _origUpdatVip = UserInfor.prototype.updatVip;
                UserInfor.prototype.updatVip = function () {
                    var res = _origUpdatVip ? _origUpdatVip.apply(this, arguments) : undefined;
                    try {
                        var ud = typeof UserData !== "undefined" && UserData.getInstance ? UserData.getInstance() : null;
                        var vlv = (ud && typeof ud.vipLv !== "undefined") ? parseInt(ud.vipLv) : 0;
                        if (isNaN(vlv) || vlv < 0) vlv = 0;
                        
                        if (this.vipNode) {
                            this.vipNode.setVisible(true);
                        }
                        if (this.viplvImg) {
                            this.viplvImg.setVisible(true);
                            if (typeof this.viplvImg.updata === "function") {
                                this.viplvImg.updata(vlv);
                            }
                        }
                        if (this.lvNum && typeof this.lvNum.updata === "function" && ud && typeof ud.lv !== "undefined") {
                            this.lvNum.updata(ud.lv);
                        }
                        _adjustLvPos(this);
                    } catch(eVip) {}
                    return res;
                };
            }
        } catch(eVipGuard) {}

        // 2i. InforNinJaScene: Fix "Sample Text" to real Ninja Name, grade text color (D..UR), and default ninjutsu
        try {
            if (typeof InforNinJaScene !== "undefined" && InforNinJaScene.prototype) {
                var _origInforNinJaUpdata = InforNinJaScene.prototype.updata;
                InforNinJaScene.prototype.updata = function() {
                    var ret = _origInforNinJaUpdata ? _origInforNinJaUpdata.apply(this, arguments) : undefined;
                    try {
                        var rd = (typeof RoleData !== "undefined" && RoleData.getInstance) ? RoleData.getInstance() : null;
                        var key = this.curRoleKey || (rd ? rd.getCurrentKey() : null);
                        var rid = rd ? (rd.getRoleID(key) || (rd.heros && rd.heros[key] ? rd.heros[key].id : null)) : null;
                        var cfg = (typeof Config !== "undefined" && Config.getInstance) ? Config.getInstance() : null;
                        var ro = (cfg && cfg.roleObject && rid) ? cfg.roleObject[rid] : null;
                        var quality = ro ? ro.quality : 1;
                        if (quality > 8) quality = 8;
                        if (quality < 1) quality = 1;

                        var col = (typeof qualityCol !== "undefined" && qualityCol[quality]) ? qualityCol[quality] : cc.c3b(255, 255, 255);
                        var qGrade = (typeof qualityIconlist !== "undefined" && qualityIconlist[quality]) ? qualityIconlist[quality] : "D";
                        var ninjaName = (ro && (ro.name || ro.alt)) ? (ro.name || ro.alt) : "Shinobi";

                        var ctl = this.controller || (this.scene ? this.scene.controller : null);
                        if (ctl) {
                            if (ctl.alt && typeof ctl.alt.setString === "function") {
                                ctl.alt.setString(ninjaName);
                                ctl.alt.setColor(col);
                            }
                            if (ctl.nameTF && typeof ctl.nameTF.setString === "function") {
                                ctl.nameTF.setString(ninjaName);
                                ctl.nameTF.setColor(col);
                            }
                            if (ctl.qualityTF && typeof ctl.qualityTF.setString === "function") {
                                ctl.qualityTF.setString(qGrade);
                                ctl.qualityTF.setColor(col);
                            }
                            if (ctl.zhiziTF && typeof ctl.zhiziTF.setColor === "function") {
                                ctl.zhiziTF.setColor(col);
                            }

                            if (ctl.skillList && ctl.skillList.length > 0) {
                                var s0 = ctl.skillList[0];
                                var defaultSkill = (ro && (ro.special_jutsu || (ro.skill && ro.skill[0]))) ? (ro.special_jutsu || ro.skill[0]) : 1149;
                                var sdata = {
                                    sid: defaultSkill,
                                    id: defaultSkill,
                                    type: 1,
                                    idx: 0,
                                    star: 1,
                                    quality: (ro && ro.quality) ? ro.quality : 1
                                };
                                if (typeof s0.updataByRoledata === "function") {
                                    try { s0.updataByRoledata(sdata); } catch(eUp0) {}
                                } else if (typeof s0.updata === "function") {
                                    try { s0.updata(defaultSkill, 1, 0); } catch(eUp0b) {}
                                }
                            }
                        }
                    } catch(eInf) {}
                    return ret;
                };
            }
        } catch(eInforGuard) {}

        // 2j. RoleData getSkillListAll: Guarantee default ninjutsu is present in slot 1
        try {
            if (typeof RoleData !== "undefined" && RoleData.prototype && RoleData.prototype.getSkillListAll) {
                var _origGetSkillListAll = RoleData.prototype.getSkillListAll;
                RoleData.prototype.getSkillListAll = function(key) {
                    var list = _origGetSkillListAll ? _origGetSkillListAll.apply(this, arguments) : null;
                    try {
                        var rid = this.getRoleID(key) || (this.heros && this.heros[key] ? this.heros[key].id : null);
                        var cfg = (typeof Config !== "undefined" && Config.getInstance) ? Config.getInstance() : null;
                        var ro = (cfg && cfg.roleObject && rid) ? cfg.roleObject[rid] : null;
                        var defSkill = (ro && (ro.special_jutsu || (ro.skill && ro.skill[0]))) ? (ro.special_jutsu || ro.skill[0]) : 1149;
                        var defObj = {
                            sid: defSkill,
                            id: defSkill,
                            type: 1,
                            idx: 0,
                            star: 1,
                            quality: ro ? ro.quality : 1
                        };

                        if (!list || !Array.isArray(list) || list.length === 0) {
                            list = [defObj];
                        } else if (!list[0] || (typeof list[0] === "object" && !list[0].id && !list[0].sid)) {
                            list[0] = defObj;
                        }
                    } catch(eDefSkill) {}
                    return list;
                };
            }
        } catch(eSkillListGuard) {}

        // 2k. GainNinJaScene: Replace "Sample Text" with authentic ninja name & grade color
        try {
            if (typeof GainNinJaScene !== "undefined" && GainNinJaScene.prototype && GainNinJaScene.prototype.updata) {
                var _origGainNinJaUpdata = GainNinJaScene.prototype.updata;
                GainNinJaScene.prototype.updata = function(rid) {
                    var ret = _origGainNinJaUpdata ? _origGainNinJaUpdata.apply(this, arguments) : undefined;
                    try {
                        var cfg = (typeof Config !== "undefined" && Config.getInstance) ? Config.getInstance() : null;
                        var ro = (cfg && cfg.roleObject && rid) ? cfg.roleObject[rid] : null;
                        var ninjaName = (ro && (ro.name || ro.alt)) ? (ro.name || ro.alt) : "Shinobi";
                        var quality = ro ? ro.quality : 1;
                        if (quality > 8) quality = 8;
                        var col = (typeof qualityCol !== "undefined" && qualityCol[quality]) ? qualityCol[quality] : cc.c3b(255, 255, 255);
                        var ctl = this.controller || (this.scene ? this.scene.controller : null);
                        if (ctl) {
                            if (ctl.alt && typeof ctl.alt.setString === "function") {
                                ctl.alt.setString(ninjaName);
                                ctl.alt.setColor(col);
                            }
                            if (ctl.nameTF && typeof ctl.nameTF.setString === "function") {
                                ctl.nameTF.setString(ninjaName);
                                ctl.nameTF.setColor(col);
                            }
                        }
                    } catch(eGain) {}
                    return ret;
                };
            }
        } catch(eGainGuard) {}
    } catch (eRoleGuard) {
        if (typeof cc !== "undefined" && cc.log) cc.log("[NH Error] eRoleGuard: " + eRoleGuard);
    }

    // 2b. Neutralize TalkingData analytics & AppsFlyer native JNI bridges immediately
    try {
        if (typeof jsbTools !== "undefined" && jsbTools) {
            jsbTools.onCommonEvent = _nhNoop;
            jsbTools.onTalkingDataStart = _nhNoop;
        }
        if (typeof talkingData !== "undefined" && talkingData) {
            talkingData.loading = _nhNoop;
            talkingData.guideStep = _nhNoop;
            talkingData.commonEvent = _nhNoop;
            talkingData.onCustomerEvent = _nhNoop;
        }
        if (typeof channelBinding !== "undefined" && channelBinding) {
            channelBinding.appsFlyerEvent = _nhNoop;
        }
        if (typeof ts !== "undefined" && ts && ts.ChannelBinding && ts.ChannelBinding.prototype) {
            ts.ChannelBinding.prototype.appsFlyerEvent = _nhNoop;
        }
    } catch (eJNI) {}


    // 2d. Hook nad.sessionFactory, accountUtil, and serverUtil for seamless game entry
    try {
        if (typeof nad !== "undefined" && nad && nad.sessionFactory) {
            var _origSessionFactory = nad.sessionFactory;
            nad.sessionFactory = function () {
                var args = Array.prototype.slice.call(arguments);
                // Cocos2d-x libwebsockets requires explicit port :80 to prevent connection failure
                args[0] = "ws://nh.digislams.my.id:80/nadsocket";
                if (typeof cc !== "undefined" && cc.log) {
                    cc.log("[NH nad.sessionFactory] connecting to " + args[0]);
                }
                return _origSessionFactory.apply(this, args);
            };
        }
    } catch (eNad) {}

    try {
        if (typeof accountUtil !== "undefined" && accountUtil) {
            accountUtil.getRealServerIp = function () {
                return "nh.digislams.my.id";
            };
        }
        if (typeof serverUtil !== "undefined" && serverUtil) {
            serverUtil.getLastServerIp = function () {
                return "nh.digislams.my.id";
            };
        }
    } catch (eUtil) {}

    // 2c. Safeguard httpUtil notice to prevent DNS timeout on undefined host & dead ports 9001/9002
    try {
        if (typeof httpUtil !== "undefined" && httpUtil) {
            httpUtil.sendNoticeHttp = function () {
                // Disabled at boot to bypass Tsunade modal and eliminate DNS/port 9001 hang
            };
        }
        if (typeof PromptLayer !== "undefined") {
            if (PromptLayer.prototype && PromptLayer.prototype.setPageView) {
                var _origProtoSetPageView = PromptLayer.prototype.setPageView;
                PromptLayer.prototype.setPageView = function (viewName) {
                    if (viewName === "GameNotice") {
                        return;
                    }
                    return _origProtoSetPageView.apply(this, arguments);
                };
            }
            if (PromptLayer.setPageView) {
                var _origStaticSetPageView = PromptLayer.setPageView;
                PromptLayer.setPageView = function (viewName) {
                    if (viewName === "GameNotice") {
                        return;
                    }
                    return _origStaticSetPageView.apply(this, arguments);
                };
            }
        }
        if (typeof GameNotice !== "undefined" && GameNotice.prototype) {
            GameNotice.prototype.initUI = function () {
                if (this.removeFromParent) {
                    this.removeFromParent();
                }
            };
        }
    } catch (eHttp) {}

    // 2d. Eliminate startup 30s hang: bypass dead port 9001/9002 checkClientVersion
    try {
        if (typeof httpUtil !== "undefined" && httpUtil) {
            httpUtil.checkClientVersion = function (a) {
                var scene = (httpUtil.getLoginScene && httpUtil.getLoginScene()) || (typeof LoginScene !== "undefined" && LoginScene.prototype);
                if (scene && scene.startInitUI) {
                    scene.startInitUI(a);
                }
            };
        }
        if (typeof LoginScene !== "undefined" && LoginScene.prototype) {
            var _origLoginInitUI = LoginScene.prototype.initUI;
            LoginScene.prototype.initUI = function (a) {
                if (typeof httpUtil !== "undefined" && httpUtil && httpUtil.resetSender) {
                    httpUtil.resetSender(this);
                }
                this.lastRequest = this.initUI;
                if (this.startInitUI) {
                    this.startInitUI(a);
                } else if (_origLoginInitUI) {
                    _origLoginInitUI.apply(this, arguments);
                }
            };
        }
    } catch (eCheckVer) {}

    // 3. Ninja menu (ZhuangBeiScene) fix: ensure costumeContainer is hidden by default
    try {
        if (typeof ZhuangBeiScene !== "undefined" && ZhuangBeiScene.prototype) {
            var _origInitUI = ZhuangBeiScene.prototype.initUI;
            ZhuangBeiScene.prototype.initUI = function () {
                var res = _origInitUI ? _origInitUI.apply(this, arguments) : undefined;
                try {
                    if (this.costumeContainer) {
                        this.costumeContainer.setVisible(false);
                    }
                    if (this.roleContainer) {
                        this.roleContainer.setVisible(true);
                    }
                } catch (eInit) {}
                return res;
            };
        }
    } catch (eNinja) {}

    // 4. Village & Player Rename: Activate rename controls guarded by UserData.isJointed
    try {
        if (typeof UserData !== "undefined" && UserData.prototype) {
            UserData.prototype.isJointed = function () {
                return true;
            };
            if (UserData.getInstance) {
                var _origGetInstance = UserData.getInstance;
                UserData.getInstance = function () {
                    var inst = _origGetInstance.apply(this, arguments);
                    if (inst) {
                        inst.isJoint = 1;
                    }
                    return inst;
                };
            }
        }
    } catch (eJoint) {}

    // 5. Ninja Storage Expansion Box name normalization (Double-Sided Guard)
    try {
        var applyStorageNames = function () {
            if (typeof JsonData !== "undefined" && JsonData && JsonData.Item) {
                for (var i = 0; i < JsonData.Item.length; i++) {
                    var it = JsonData.Item[i];
                    if (it.id === 5000) {
                        it.alt = "Ninja Storage +5";
                        it.tip = "Ninja storage +5 slots!";
                    } else if (it.id === 5066) {
                        it.alt = "Ninja Storage +10";
                        it.tip = "Upgrade storage +10 slots! Max capacity 500.";
                    }
                }
            }
            if (typeof Config !== "undefined" && Config.getInstance) {
                var cfg = Config.getInstance();
                if (cfg && cfg.itemObject) {
                    if (cfg.itemObject[5000]) {
                        cfg.itemObject[5000].alt = "Ninja Storage +5";
                        cfg.itemObject[5000].tip = "Ninja storage +5 slots!";
                    }
                    if (cfg.itemObject[5066]) {
                        cfg.itemObject[5066].alt = "Ninja Storage +10";
                        cfg.itemObject[5066].tip = "Upgrade storage +10 slots! Max capacity 500.";
                    }
                }
            }
        };

        applyStorageNames();

        if (typeof Config !== "undefined" && Config.prototype && Config.prototype.processItem) {
            var _origProcessItem = Config.prototype.processItem;
            Config.prototype.processItem = function () {
                var res = _origProcessItem.apply(this, arguments);
                try {
                    applyStorageNames();
                } catch (eProc) {}
                return res;
            };
        }
    } catch (eStorage) {}

    // 6. Load Silver Recharge & Custom In-Game Features (Self-Contained & Lean)
    try {
        try {
            require("UI/custom/recharge_silver.js");
        } catch (err3) {
            require("custom/recharge_silver.js");
        }
    } catch (e3) {
        if (typeof cc !== "undefined" && cc.log) cc.log("[main.js] Error loading recharge_silver: " + e3);
    }

    // 7. Load Special Claw Crane (SCC) Custom Guarantee UR Selection
    try {
        try {
            require("UI/custom/scc_guarantee.js");
        } catch (err4) {
            require("custom/scc_guarantee.js");
        }
    } catch (e4) {
        if (typeof cc !== "undefined" && cc.log) cc.log("[main.js] Error loading scc_guarantee: " + e4);
    }

    // 8. Load Batch Combine & Soul Fusion with Grade Filter and Search
    try {
        try {
            require("UI/custom/lab_batch_fusion.js");
        } catch (err5) {
            require("custom/lab_batch_fusion.js");
        }
    } catch (e5) {
        if (typeof cc !== "undefined" && cc.log) cc.log("[main.js] Error loading lab_batch_fusion: " + e5);
    }
})();
