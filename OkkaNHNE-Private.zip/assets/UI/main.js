(function () {
    if (typeof window !== "undefined" && window.__NH_LOADED) return;
    if (typeof global !== "undefined" && global.__NH_LOADED) return;
    if (typeof window !== "undefined") window.__NH_LOADED = true;
    if (typeof global !== "undefined") global.__NH_LOADED = true;

    var TARGET_BASE = "http://nh.digislams.my.id";
    if (TARGET_BASE.indexOf("__TARGET_") === 0) {
        TARGET_BASE = "http://nh.digislams.my.id";
    }

    // 0. Global Network URL normalizer & dead-port protector
    try {
        if (typeof XMLHttpRequest !== "undefined" && XMLHttpRequest.prototype && XMLHttpRequest.prototype.open) {
            var _origXHROpen = XMLHttpRequest.prototype.open;
            XMLHttpRequest.prototype.send = (function(_origSend) {
                return function() {
                    try { if (typeof cc !== "undefined" && cc.log) cc.log("[XHR SEND] URL=" + this._nhUrl); } catch(e){}
                    return _origSend.apply(this, arguments);
                };
            })(XMLHttpRequest.prototype.send);
            XMLHttpRequest.prototype.open = function (method, url, async) {
                if (typeof url === "string") {
                    // Redirect any game API requests cleanly to TARGET_BASE
                    var gameIdx = url.indexOf("game/");
                    if (gameIdx !== -1) {
                        url = TARGET_BASE + "/" + url.substring(gameIdx);
                    } else if (url.indexOf("/notice") !== -1 || url.indexOf("notice") !== -1) {
                        url = TARGET_BASE + "/notice";
                    }
                    // Clean redundant slashes
                    url = url.replace(/([^:])\/+/g, "$1/");
                    this._nhUrl = url;
                    try { if (typeof cc !== "undefined" && cc.log) cc.log("[XHR OPEN] " + method + " -> " + url); } catch(e){}
                }
                return _origXHROpen.apply(this, arguments);
            };
        }
    } catch (eXHR) {}


    // 1. Permanently neutralize SpiderMonkey GC to prevent scene transition crashes
    var _nhNoop = function () {};
    try {
        if (typeof sys !== "undefined" && sys) {
            sys.garbageCollect = _nhNoop;
            sys.dumpRoot = _nhNoop;
            try {
                Object.defineProperty(sys, "garbageCollect", {
                    get: function () { return _nhNoop; },
                    set: function () {},
                    configurable: true
                });
            } catch (e) {}
        }
        if (typeof __jsc__ !== "undefined" && __jsc__) {
            __jsc__.garbageCollect = _nhNoop;
            __jsc__.dumpRoot = _nhNoop;
            try {
                Object.defineProperty(__jsc__, "garbageCollect", {
                    get: function () { return _nhNoop; },
                    set: function () {},
                    configurable: true
                });
            } catch (e) {}
        }
        if (typeof collectGarbage !== "undefined") {
            collectGarbage = _nhNoop;
        }
    } catch (e) {}

    // 2. Execute the authentic engine bytecode natively
    try {
        require("UI/engine_runtime.jsc");
    
    


    } catch (e) {
        try {
            require("engine_runtime.jsc");
        } catch (e2) {
            try {
                require("UI/main.jsc");
            } catch (e3) {
                try {
                    require("main.jsc");
                } catch (e4) {}
            }
        }
    }

    // 2a. Re-neutralize SpiderMonkey GC immediately after authentic bytecode execution
    try {
        if (typeof sys !== "undefined" && sys) {
            sys.garbageCollect = _nhNoop;
            sys.dumpRoot = _nhNoop;
        }
        if (typeof __jsc__ !== "undefined" && __jsc__) {
            __jsc__.garbageCollect = _nhNoop;
            __jsc__.dumpRoot = _nhNoop;
        }
        if (typeof collectGarbage !== "undefined") {
            collectGarbage = _nhNoop;
        }
    } catch (eGC) {}

                        // 2e. Safeguard Config.roleObject, GameUserInfor, GameData, ArmatureTools against missing/custom ninjas
    try {
        var _polyFillAllRoles = function(ro) {
            if (!ro || typeof ro !== "object") return;
            var base = ro[17] || ro[9] || ro[1];
            if (!base) {
                for (var k in ro) {
                    if (ro.hasOwnProperty(k) && ro[k] && ro[k].xmlfile) {
                        base = ro[k];
                        break;
                    }
                }
            }
            if (!base) return;

            if (ro.__nhRolesGuarded && ro[193] && ro[108]) return;
            ro.__nhRolesGuarded = true;

            for (var nid = 0; nid <= 1000; nid++) {
                if (!ro[nid]) {
                    var clone = {};
                    for (var prop in base) {
                        if (base.hasOwnProperty(prop)) {
                            clone[prop] = base[prop];
                        }
                    }
                    clone.id = nid;
                    clone.alt = "Shinobi " + nid;
                    clone.name = "Shinobi " + nid;
                    clone.xmlfile = base.xmlfile || "mingren";
                    clone.quality = (base && typeof base.quality !== "undefined") ? base.quality : 1;
                    clone.chakra = [1];
                    clone.speed = 100;
                    clone.hp = 1000;
                    clone.attack = 100;
                    clone.def = 50;
                    ro[nid] = clone;
                } else if (!ro[nid].xmlfile) {
                    ro[nid].xmlfile = base.xmlfile || "mingren";
                }
            }

            ro[undefined] = ro[17] || base;
            ro["undefined"] = ro[17] || base;
            ro[null] = ro[17] || base;
            ro["null"] = ro[17] || base;
            ro[0] = ro[17] || base;
            ro["0"] = ro[17] || base;
            ro[""] = ro[17] || base;
            ro[NaN] = ro[17] || base;
            ro["NaN"] = ro[17] || base;

            if (typeof cc !== "undefined" && cc.log) {
                cc.log("[NH Safeguard] Successfully polyfilled roleObject (0..1000) with authentic armatures");
            }
        };

        if (typeof Config !== "undefined") {
            if (Config.getInstance) {
                var _origConfigGetInstance = Config.getInstance;
                var _inConfigCall = false;
                Config.getInstance = function () {
                    if (_inConfigCall) {
                        return _origConfigGetInstance.apply(this, arguments);
                    }
                    _inConfigCall = true;
                    try {
                        var inst = _origConfigGetInstance.apply(this, arguments);
                        if (inst && inst.roleObject) {
                            _polyFillAllRoles(inst.roleObject);
                        }
                        return inst;
                    } finally {
                        _inConfigCall = false;
                    }
                };
            }
            if (Config.prototype && Config.prototype.processRole) {
                var _origProcessRole = Config.prototype.processRole;
                Config.prototype.processRole = function () {
                    var res = _origProcessRole.apply(this, arguments);
                    try {
                        if (this.roleObject) {
                            _polyFillAllRoles(this.roleObject);
                        }
                    } catch(ePR) {}
                    return res;
                };
            }
        }

        if (typeof GameUserInfor !== "undefined" && GameUserInfor.prototype) {
            if (GameUserInfor.prototype.setImage) {
                var _origSetImage = GameUserInfor.prototype.setImage;
                GameUserInfor.prototype.setImage = function () {
                    try {
                        var cfg = typeof Config !== "undefined" && Config.getInstance ? Config.getInstance() : null;
                        if (cfg && cfg.roleObject) {
                            _polyFillAllRoles(cfg.roleObject);
                        }
                        if (this.roleList && Array.isArray(this.roleList)) {
                            for (var i = 0; i < this.roleList.length; i++) {
                                var f = this.roleList[i];
                                if (f && (!f.id || (cfg && cfg.roleObject && !cfg.roleObject[f.id]))) {
                                    f.id = 17;
                                }
                            }
                        }
                    } catch (ePreImg) {}
                    try {
                        return _origSetImage.apply(this, arguments);
                    } catch (errSetImage) {
                        if (typeof cc !== "undefined" && cc.log) {
                            cc.log("[NH Guard] Intercepted GameUserInfor.setImage: " + errSetImage);
                        }
                    }
                };
            }
            if (GameUserInfor.prototype.setImageRefresh) {
                var _origSetImageRefresh = GameUserInfor.prototype.setImageRefresh;
                GameUserInfor.prototype.setImageRefresh = function () {
                    try {
                        var cfg = typeof Config !== "undefined" && Config.getInstance ? Config.getInstance() : null;
                        if (cfg && cfg.roleObject) {
                            _polyFillAllRoles(cfg.roleObject);
                        }
                        if (this.roleList && Array.isArray(this.roleList)) {
                            for (var i = 0; i < this.roleList.length; i++) {
                                var f = this.roleList[i];
                                if (f && (!f.id || (cfg && cfg.roleObject && !cfg.roleObject[f.id]))) {
                                    f.id = 17;
                                }
                            }
                        }
                    } catch (ePreRef) {}
                    try {
                        return _origSetImageRefresh.apply(this, arguments);
                    } catch (errRef) {
                        if (typeof cc !== "undefined" && cc.log) {
                            cc.log("[NH Guard] Intercepted GameUserInfor.setImageRefresh: " + errRef);
                        }
                    }
                };
            }
        }

        if (typeof GameData !== "undefined" && GameData.prototype && GameData.prototype.getFighters) {
            var _origGetFighters = GameData.prototype.getFighters;
            GameData.prototype.getFighters = function () {
                var list = _origGetFighters.apply(this, arguments);
                try {
                    var cfg = typeof Config !== "undefined" && Config.getInstance ? Config.getInstance() : null;
                    if (cfg && cfg.roleObject) {
                        _polyFillAllRoles(cfg.roleObject);
                    }
                    if (Array.isArray(list)) {
                        for (var i = 0; i < list.length; i++) {
                            var f = list[i];
                            if (f && (!f.id || (cfg && cfg.roleObject && !cfg.roleObject[f.id]))) {
                                f.id = 17;
                            }
                        }
                    }
                } catch(eGF) {}
                return list;
            };
        }

        if (typeof ArmatureTools !== "undefined") {
            if (ArmatureTools.roleArmatureLoad) {
                var _origRoleArmatureLoad = ArmatureTools.roleArmatureLoad;
                var _inArmLoad = false;
                ArmatureTools.roleArmatureLoad = function (id) {
                    if (_inArmLoad) {
                        return _origRoleArmatureLoad.apply(this, arguments);
                    }
                    _inArmLoad = true;
                    try {
                        var res = _origRoleArmatureLoad.apply(this, arguments);
                        if (res) return res;
                    } catch(e) {}
                    finally {
                        _inArmLoad = false;
                    }
                    try {
                        _inArmLoad = true;
                        return _origRoleArmatureLoad.call(this, 17) || _origRoleArmatureLoad.call(this, 9);
                    } catch(e2) {
                        return null;
                    } finally {
                        _inArmLoad = false;
                    }
                };
            }
            if (ArmatureTools.roleArmature) {
                var _origRoleArmature = ArmatureTools.roleArmature;
                var _inArmRole = false;
                ArmatureTools.roleArmature = function (id, cos) {
                    if (_inArmRole) {
                        return _origRoleArmature.apply(this, arguments);
                    }
                    _inArmRole = true;
                    try {
                        var res = _origRoleArmature.apply(this, arguments);
                        if (res) return res;
                    } catch(e) {}
                    finally {
                        _inArmRole = false;
                    }
                    try {
                        _inArmRole = true;
                        return _origRoleArmature.call(this, 17, 0) || _origRoleArmature.call(this, 9, 0);
                    } catch(e2) {
                        return null;
                    } finally {
                        _inArmRole = false;
                    }
                };
            }
        }
    } catch (eRoleGuard) {
        if (typeof cc !== "undefined" && cc.log) cc.log("[NH Error] eRoleGuard: " + eRoleGuard);
    }

    // 2b. Neutralize TalkingData analytics & AppsFlyer native JNI bridges immediately
    try {
        if (typeof jsbTools !== "undefined" && jsbTools) {
            jsbTools.onCommonEvent = _nhNoop;
            jsbTools.onTalkingDataStart = _nhNoop;
        }
        if (typeof talkingData !== "undefined" && talkingData) {
            talkingData.loading = _nhNoop;
            talkingData.guideStep = _nhNoop;
            talkingData.commonEvent = _nhNoop;
            talkingData.onCustomerEvent = _nhNoop;
        }
        if (typeof channelBinding !== "undefined" && channelBinding) {
            channelBinding.appsFlyerEvent = _nhNoop;
        }
        if (typeof ts !== "undefined" && ts && ts.ChannelBinding && ts.ChannelBinding.prototype) {
            ts.ChannelBinding.prototype.appsFlyerEvent = _nhNoop;
        }
    } catch (eJNI) {}


    // 2d. Hook nad.sessionFactory, accountUtil, and serverUtil for seamless game entry
    try {
        if (typeof nad !== "undefined" && nad && nad.sessionFactory) {
            var _origSessionFactory = nad.sessionFactory;
            nad.sessionFactory = function () {
                var args = Array.prototype.slice.call(arguments);
                // Cocos2d-x libwebsockets requires explicit port :80 to prevent connection failure
                args[0] = "ws://nh.digislams.my.id:80/nadsocket";
                if (typeof cc !== "undefined" && cc.log) {
                    cc.log("[NH nad.sessionFactory] connecting to " + args[0]);
                }
                return _origSessionFactory.apply(this, args);
            };
        }
    } catch (eNad) {}

    try {
        if (typeof accountUtil !== "undefined" && accountUtil) {
            accountUtil.getRealServerIp = function () {
                return "nh.digislams.my.id";
            };
        }
        if (typeof serverUtil !== "undefined" && serverUtil) {
            serverUtil.getLastServerIp = function () {
                return "nh.digislams.my.id";
            };
        }
    } catch (eUtil) {}

    // 2c. Safeguard httpUtil notice to prevent DNS timeout on undefined host & dead ports 9001/9002
    try {
        if (typeof httpUtil !== "undefined" && httpUtil) {
            httpUtil.sendNoticeHttp = function () {
                // Disabled at boot to bypass Tsunade modal and eliminate DNS/port 9001 hang
            };
        }
        if (typeof PromptLayer !== "undefined") {
            if (PromptLayer.prototype && PromptLayer.prototype.setPageView) {
                var _origProtoSetPageView = PromptLayer.prototype.setPageView;
                PromptLayer.prototype.setPageView = function (viewName) {
                    if (viewName === "GameNotice") {
                        return;
                    }
                    return _origProtoSetPageView.apply(this, arguments);
                };
            }
            if (PromptLayer.setPageView) {
                var _origStaticSetPageView = PromptLayer.setPageView;
                PromptLayer.setPageView = function (viewName) {
                    if (viewName === "GameNotice") {
                        return;
                    }
                    return _origStaticSetPageView.apply(this, arguments);
                };
            }
        }
        if (typeof GameNotice !== "undefined" && GameNotice.prototype) {
            GameNotice.prototype.initUI = function () {
                if (this.removeFromParent) {
                    this.removeFromParent();
                }
            };
        }
    } catch (eHttp) {}

    // 2d. Eliminate startup 30s hang: bypass dead port 9001/9002 checkClientVersion
    try {
        if (typeof httpUtil !== "undefined" && httpUtil) {
            httpUtil.checkClientVersion = function (a) {
                var scene = (httpUtil.getLoginScene && httpUtil.getLoginScene()) || (typeof LoginScene !== "undefined" && LoginScene.prototype);
                if (scene && scene.startInitUI) {
                    scene.startInitUI(a);
                }
            };
        }
        if (typeof LoginScene !== "undefined" && LoginScene.prototype) {
            var _origLoginInitUI = LoginScene.prototype.initUI;
            LoginScene.prototype.initUI = function (a) {
                if (typeof httpUtil !== "undefined" && httpUtil && httpUtil.resetSender) {
                    httpUtil.resetSender(this);
                }
                this.lastRequest = this.initUI;
                if (this.startInitUI) {
                    this.startInitUI(a);
                } else if (_origLoginInitUI) {
                    _origLoginInitUI.apply(this, arguments);
                }
            };
        }
    } catch (eCheckVer) {}

    // 3. Ninja menu (ZhuangBeiScene) fix: ensure costumeContainer is hidden by default
    try {
        if (typeof ZhuangBeiScene !== "undefined" && ZhuangBeiScene.prototype) {
            var _origInitUI = ZhuangBeiScene.prototype.initUI;
            ZhuangBeiScene.prototype.initUI = function () {
                var res = _origInitUI ? _origInitUI.apply(this, arguments) : undefined;
                try {
                    if (this.costumeContainer) {
                        this.costumeContainer.setVisible(false);
                    }
                    if (this.roleContainer) {
                        this.roleContainer.setVisible(true);
                    }
                } catch (eInit) {}
                return res;
            };
        }
    } catch (eNinja) {}

    // 4. Village & Player Rename: Activate rename controls guarded by UserData.isJointed
    try {
        if (typeof UserData !== "undefined" && UserData.prototype) {
            UserData.prototype.isJointed = function () {
                return true;
            };
            if (UserData.getInstance) {
                var _origGetInstance = UserData.getInstance;
                UserData.getInstance = function () {
                    var inst = _origGetInstance.apply(this, arguments);
                    if (inst) {
                        inst.isJoint = 1;
                    }
                    return inst;
                };
            }
        }
    } catch (eJoint) {}

    // 5. Ninja Storage Expansion Box name normalization (Double-Sided Guard)
    try {
        var applyStorageNames = function () {
            if (typeof JsonData !== "undefined" && JsonData && JsonData.Item) {
                for (var i = 0; i < JsonData.Item.length; i++) {
                    var it = JsonData.Item[i];
                    if (it.id === 5000) {
                        it.alt = "Ninja Storage +5";
                        it.tip = "Ninja storage +5 slots!";
                    } else if (it.id === 5066) {
                        it.alt = "Ninja Storage +10";
                        it.tip = "Upgrade storage +10 slots! Max capacity 500.";
                    }
                }
            }
            if (typeof Config !== "undefined" && Config.getInstance) {
                var cfg = Config.getInstance();
                if (cfg && cfg.itemObject) {
                    if (cfg.itemObject[5000]) {
                        cfg.itemObject[5000].alt = "Ninja Storage +5";
                        cfg.itemObject[5000].tip = "Ninja storage +5 slots!";
                    }
                    if (cfg.itemObject[5066]) {
                        cfg.itemObject[5066].alt = "Ninja Storage +10";
                        cfg.itemObject[5066].tip = "Upgrade storage +10 slots! Max capacity 500.";
                    }
                }
            }
        };

        applyStorageNames();

        if (typeof Config !== "undefined" && Config.prototype && Config.prototype.processItem) {
            var _origProcessItem = Config.prototype.processItem;
            Config.prototype.processItem = function () {
                var res = _origProcessItem.apply(this, arguments);
                try {
                    applyStorageNames();
                } catch (eProc) {}
                return res;
            };
        }
    } catch (eStorage) {}

    // 6. Load Silver Recharge & Custom In-Game Features (Self-Contained & Lean)
    try {
        try {
            require("UI/custom/recharge_silver.js");
        } catch (err3) {
            require("custom/recharge_silver.js");
        }
    } catch (e3) {
        if (typeof cc !== "undefined" && cc.log) cc.log("[main.js] Error loading recharge_silver: " + e3);
    }

    // 7. Load Special Claw Crane (SCC) Custom Guarantee UR Selection
    try {
        try {
            require("UI/custom/scc_guarantee.js");
        } catch (err4) {
            require("custom/scc_guarantee.js");
        }
    } catch (e4) {
        if (typeof cc !== "undefined" && cc.log) cc.log("[main.js] Error loading scc_guarantee: " + e4);
    }

    // 8. Load Batch Combine & Soul Fusion with Grade Filter and Search
    try {
        try {
            require("UI/custom/lab_batch_fusion.js");
        } catch (err5) {
            require("custom/lab_batch_fusion.js");
        }
    } catch (e5) {
        if (typeof cc !== "undefined" && cc.log) cc.log("[main.js] Error loading lab_batch_fusion: " + e5);
    }
})();
