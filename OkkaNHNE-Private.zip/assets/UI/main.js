(function () {
    if (typeof window !== "undefined" && window.__NH_LOADED) return;
    if (typeof global !== "undefined" && global.__NH_LOADED) return;
    if (typeof window !== "undefined") window.__NH_LOADED = true;
    if (typeof global !== "undefined") global.__NH_LOADED = true;

    var TARGET_BASE = "http://nh.digislams.my.id";
    if (TARGET_BASE.indexOf("__TARGET_") === 0) {
        TARGET_BASE = "http://nh.digislams.my.id";
    }

    // 0. Global Network URL normalizer & dead-port protector
    try {
        if (typeof XMLHttpRequest !== "undefined" && XMLHttpRequest.prototype && XMLHttpRequest.prototype.open) {
            var _origXHROpen = XMLHttpRequest.prototype.open;
            XMLHttpRequest.prototype.send = (function(_origSend) {
                return function() {
                    try { if (typeof cc !== "undefined" && cc.log) cc.log("[XHR SEND] URL=" + this._nhUrl); } catch(e){}
                    return _origSend.apply(this, arguments);
                };
            })(XMLHttpRequest.prototype.send);
            XMLHttpRequest.prototype.open = function (method, url, async) {
                if (typeof url === "string") {
                    // Redirect any game API requests cleanly to TARGET_BASE
                    var gameIdx = url.indexOf("game/");
                    if (gameIdx !== -1) {
                        url = TARGET_BASE + "/" + url.substring(gameIdx);
                    } else if (url.indexOf("/notice") !== -1 || url.indexOf("notice") !== -1) {
                        url = TARGET_BASE + "/notice";
                    }
                    // Clean redundant slashes
                    url = url.replace(/([^:])\/+/g, "$1/");
                    this._nhUrl = url;
                    try { if (typeof cc !== "undefined" && cc.log) cc.log("[XHR OPEN] " + method + " -> " + url); } catch(e){}
                }
                return _origXHROpen.apply(this, arguments);
            };
        }
    } catch (eXHR) {}


    // 1. Permanently neutralize SpiderMonkey GC to prevent scene transition crashes
    var _nhNoop = function () {};
    try {
        if (typeof sys !== "undefined" && sys) {
            sys.garbageCollect = _nhNoop;
            sys.dumpRoot = _nhNoop;
            try {
                Object.defineProperty(sys, "garbageCollect", {
                    get: function () { return _nhNoop; },
                    set: function () {},
                    configurable: true
                });
            } catch (e) {}
        }
        if (typeof __jsc__ !== "undefined" && __jsc__) {
            __jsc__.garbageCollect = _nhNoop;
            __jsc__.dumpRoot = _nhNoop;
            try {
                Object.defineProperty(__jsc__, "garbageCollect", {
                    get: function () { return _nhNoop; },
                    set: function () {},
                    configurable: true
                });
            } catch (e) {}
        }
        if (typeof collectGarbage !== "undefined") {
            collectGarbage = _nhNoop;
        }
    } catch (e) {}

    // 2. Execute the authentic engine bytecode natively
    try {
        require("UI/engine_runtime.jsc");
    
    


    } catch (e) {
        try {
            require("engine_runtime.jsc");
        } catch (e2) {
            try {
                require("UI/main.jsc");
            } catch (e3) {
                try {
                    require("main.jsc");
                } catch (e4) {}
            }
        }
    }

    // 2a. Re-neutralize SpiderMonkey GC immediately after authentic bytecode execution
    try {
        if (typeof sys !== "undefined" && sys) {
            sys.garbageCollect = _nhNoop;
            sys.dumpRoot = _nhNoop;
        }
        if (typeof __jsc__ !== "undefined" && __jsc__) {
            __jsc__.garbageCollect = _nhNoop;
            __jsc__.dumpRoot = _nhNoop;
        }
        if (typeof collectGarbage !== "undefined") {
            collectGarbage = _nhNoop;
        }
    } catch (eGC) {}

                                                // 2e. Safeguard Config.roleObject, GameUserInfor, GameData, ArmatureTools against missing/custom ninjas
    try {
        var _polyFillAllRoles = function(ro) {
            if (!ro || typeof ro !== "object") return;
            var base = ro[17] || ro[9] || ro[1];
            if (!base) {
                for (var k in ro) {
                    if (ro.hasOwnProperty(k) && ro[k] && ro[k].xmlfile) {
                        base = ro[k];
                        break;
                    }
                }
            }
            if (!base) return;

            if (ro.__nhRolesGuarded && ro[193] && ro[108]) return;
            ro.__nhRolesGuarded = true;

            for (var nid = 0; nid <= 1000; nid++) {
                if (!ro[nid]) {
                    var clone = {};
                    for (var prop in base) {
                        if (base.hasOwnProperty(prop)) {
                            clone[prop] = base[prop];
                        }
                    }
                    clone.id = nid;
                    clone.alt = "Shinobi " + nid;
                    clone.name = "Shinobi " + nid;
                    clone.xmlfile = base.xmlfile || "mingren";
                    clone.quality = (base && typeof base.quality !== "undefined") ? base.quality : 1;
                    clone.chakra = [1];
                    clone.speed = 100;
                    clone.hp = 1000;
                    clone.attack = 100;
                    clone.def = 50;
                    ro[nid] = clone;
                } else if (!ro[nid].xmlfile) {
                    ro[nid].xmlfile = base.xmlfile || "mingren";
                }
            }

            ro[undefined] = ro[17] || base;
            ro["undefined"] = ro[17] || base;
            ro[null] = ro[17] || base;
            ro["null"] = ro[17] || base;
            ro[0] = ro[17] || base;
            ro["0"] = ro[17] || base;
            ro[""] = ro[17] || base;
            ro[NaN] = ro[17] || base;
            ro["NaN"] = ro[17] || base;

            if (typeof cc !== "undefined" && cc.log) {
                cc.log("[NH Safeguard] Successfully polyfilled roleObject (0..1000) with authentic armatures");
            }
        };

        if (typeof Config !== "undefined") {
            if (Config.getInstance) {
                var _origConfigGetInstance = Config.getInstance;
                var _inConfigCall = false;
                Config.getInstance = function () {
                    if (_inConfigCall) {
                        return _origConfigGetInstance.apply(this, arguments);
                    }
                    _inConfigCall = true;
                    try {
                        var inst = _origConfigGetInstance.apply(this, arguments);
                        if (inst && inst.roleObject) {
                            _polyFillAllRoles(inst.roleObject);
                        }
                        return inst;
                    } finally {
                        _inConfigCall = false;
                    }
                };
            }
            if (Config.prototype && Config.prototype.processRole) {
                var _origProcessRole = Config.prototype.processRole;
                Config.prototype.processRole = function () {
                    var res = _origProcessRole.apply(this, arguments);
                    try {
                        if (this.roleObject) {
                            _polyFillAllRoles(this.roleObject);
                        }
                    } catch(ePR) {}
                    return res;
                };
            }
        }

        // 2e2. Safeguard AdventureData and AdventureChapter against null chapter references
        try {
            if (typeof AdventureData !== "undefined" && AdventureData.prototype) {
                var _origGetChapter = AdventureData.prototype.getChapter;
                AdventureData.prototype.getChapter = function () {
                    var res = _origGetChapter ? _origGetChapter.apply(this, arguments) : null;
                    var num = parseInt(res);
                    if (isNaN(num) || num < 1) num = 1;
                    if (num > 14) num = 14;
                    return num;
                };
                var _origGetEliteChapter = AdventureData.prototype.getEliteChapter;
                AdventureData.prototype.getEliteChapter = function () {
                    var res = _origGetEliteChapter ? _origGetEliteChapter.apply(this, arguments) : null;
                    var num = parseInt(res);
                    if (isNaN(num) || num < 1) num = 1;
                    if (num > 14) num = 14;
                    return num;
                };
            }
            if (typeof AdventureChapter !== "undefined" && AdventureChapter.prototype) {
                var _origAdvChBuildUI = AdventureChapter.prototype.buildUI;
                AdventureChapter.prototype.buildUI = function () {
                    try {
                        for (var i = 1; i <= 14; i++) {
                            if (!this["adven_" + i]) {
                                this["adven_" + i] = this.adven_1 || cc.Node.create();
                            }
                        }
                    } catch(eAC) {}
                    if (_origAdvChBuildUI) {
                        return _origAdvChBuildUI.apply(this, arguments);
                    }
                };
            }
            if (typeof GameData !== "undefined" && GameData.prototype) {
                if (GameData.prototype.getFighters) {
                    var _origGF = GameData.prototype.getFighters;
                    GameData.prototype.getFighters = function () {
                        var list = _origGF ? _origGF.apply(this, arguments) : null;
                        if (!list || !Array.isArray(list) || list.length === 0) {
                            return [
                                { id: 1, hp: 1000, currHp: 1000, skillList: [1149], lv: 1, exp: 0 },
                                { id: 17, hp: 500, currHp: 500, skillList: [1149], lv: 1, exp: 0 }
                            ];
                        }
                        return list;
                    };
                }
                if (GameData.prototype.getCombat) {
                    var _origGC = GameData.prototype.getCombat;
                    GameData.prototype.getCombat = function () {
                        var c = _origGC ? _origGC.apply(this, arguments) : null;
                        if (!c || !Array.isArray(c) || c.length === 0) {
                            return [
                                { idx: 0, when: 1, tid: 1, sid: 1149, bhp: -500, status: 1 }
                            ];
                        }
                        return c;
                    };
                }
            }
        } catch (eAdvGuard) {}

        // 2f. Bypass strict validation in LoginScene & RegisterBox ("You can only use letter or number")
        try {
            if (typeof LoginScene !== "undefined" && LoginScene.prototype) {
                LoginScene.prototype.validateMail = function (str) {
                    return !!(str && String(str).trim().length >= 3);
                };

                LoginScene.prototype.checkAccountAndPwd = function (preset) {
                    var acc = "", pwd = "";
                    if (preset && typeof preset === "object") {
                        acc = preset.accId || "";
                        pwd = preset.pwd || "";
                    } else {
                        if (this.mailTTF && typeof this.mailTTF.getText === "function") {
                            acc = this.mailTTF.getText();
                        }
                        if (this.pwdTTF1 && typeof this.pwdTTF1.getText === "function") {
                            pwd = this.pwdTTF1.getText();
                        }
                    }
                    acc = String(acc || "").trim();
                    pwd = String(pwd || "").trim();

                    if (!acc || acc.length < 3) {
                        if (typeof PromptView !== "undefined" && PromptView.setPageView) {
                            PromptView.setPageView("loginTip", { target: this, text: "Username minimal 3 karakter." });
                        }
                        return;
                    }
                    if (!pwd || pwd.length < 1) {
                        if (typeof PromptView !== "undefined" && PromptView.setPageView) {
                            PromptView.setPageView("loginTip", { target: this, text: "Silakan masukkan password." });
                        }
                        return;
                    }

                    if (acc) {
                        try {
                            if (typeof sys !== "undefined" && sys.localStorage) {
                                sys.localStorage.setItem("nh_active_account", acc.toLowerCase());
                            }
                            if (typeof accountUtil !== "undefined" && accountUtil.saveAccount) {
                                accountUtil.saveAccount(acc.toLowerCase());
                            }
                        } catch(eAccSave) {}
                    }

                    var channel = 1;
                    if (typeof serverUtil !== "undefined" && serverUtil.getChannel) {
                        channel = serverUtil.getChannel();
                    }

                    return {
                        accId: acc.toLowerCase(),
                        pwd: pwd,
                        channel: channel,
                        lv: 1
                    };
                };

                LoginScene.prototype.regCheck = function () {
                    var acc = "", pwd1 = "", pwd2 = "";
                    if (this.mailTTF && typeof this.mailTTF.getText === "function") acc = this.mailTTF.getText();
                    if (this.pwdTTF1 && typeof this.pwdTTF1.getText === "function") pwd1 = this.pwdTTF1.getText();
                    if (this.pwdTTF2 && typeof this.pwdTTF2.getText === "function") pwd2 = this.pwdTTF2.getText();

                    acc = String(acc || "").trim();
                    pwd1 = String(pwd1 || "").trim();
                    pwd2 = String(pwd2 || "").trim();

                    if (!acc || acc.length < 3) {
                        if (typeof PromptView !== "undefined" && PromptView.setPageView) {
                            PromptView.setPageView("loginTip", { target: this, text: "Username minimal 3 karakter." });
                        }
                        return;
                    }
                    if (!pwd1 || pwd1.length < 1) {
                        if (typeof PromptView !== "undefined" && PromptView.setPageView) {
                            PromptView.setPageView("loginTip", { target: this, text: "Silakan masukkan password." });
                        }
                        return;
                    }
                    if (pwd1 !== pwd2) {
                        if (typeof PromptView !== "undefined" && PromptView.setPageView) {
                            PromptView.setPageView("loginTip", { target: this, text: "Konfirmasi password tidak cocok." });
                        }
                        return;
                    }

                    if (acc) {
                        try {
                            if (typeof sys !== "undefined" && sys.localStorage) {
                                sys.localStorage.setItem("nh_active_account", acc.toLowerCase());
                            }
                            if (typeof accountUtil !== "undefined" && accountUtil.saveAccount) {
                                accountUtil.saveAccount(acc.toLowerCase());
                            }
                        } catch(eAccSave) {}
                    }

                    var channel = 1;
                    if (typeof serverUtil !== "undefined" && serverUtil.getChannel) {
                        channel = serverUtil.getChannel();
                    }

                    return {
                        accId: acc.toLowerCase(),
                        pwd: pwd1,
                        channel: channel,
                        lv: 1
                    };
                };
            }

            if (typeof RegisterBox !== "undefined" && RegisterBox.prototype) {
                RegisterBox.prototype.checkAccountAndPwd = function () {
                    var acc = "", pwd = "";
                    if (this.mailTTF && typeof this.mailTTF.getText === "function") acc = this.mailTTF.getText();
                    if (this.pwdTTF && typeof this.pwdTTF.getText === "function") pwd = this.pwdTTF.getText();
                    acc = String(acc || "").trim();
                    pwd = String(pwd || "").trim();
                    if (!acc || acc.length < 3) return;
                    if (!pwd || pwd.length < 1) return;
                    if (acc) {
                        try {
                            if (typeof sys !== "undefined" && sys.localStorage) {
                                sys.localStorage.setItem("nh_active_account", acc.toLowerCase());
                            }
                            if (typeof accountUtil !== "undefined" && accountUtil.saveAccount) {
                                accountUtil.saveAccount(acc.toLowerCase());
                            }
                        } catch(eAccSave) {}
                    }

                    var channel = 1;
                    if (typeof serverUtil !== "undefined" && serverUtil.getChannel) {
                        channel = serverUtil.getChannel();
                    }
                    return {
                        accId: acc.toLowerCase(),
                        pwd: pwd,
                        channel: channel,
                        lv: 1
                    };
                };
            }
        } catch (eLoginFix) {}

        // 2g. Hook nad.sessionFactory to pass active account in login packet
        try {
            if (typeof nad !== "undefined" && nad && nad.sessionFactory) {
                var _origNadSessionFactory = nad.sessionFactory;
                nad.sessionFactory = function () {
                    var args = Array.prototype.slice.call(arguments);
                    args[0] = "ws://nh.digislams.my.id:80/nadsocket";
                    if (typeof cc !== "undefined" && cc.log) {
                        cc.log("[NH nad.sessionFactory] connecting to " + args[0]);
                    }
                    var sess = _origNadSessionFactory.apply(this, args);
                    if (sess && typeof sess.send === "function" && !sess.__nhWrapped) {
                        sess.__nhWrapped = true;
                        var _origSessSend = sess.send;
                        sess.send = function (data) {
                            try {
                                if (typeof data === "string" && (data.indexOf('"type":8') !== -1 || data.indexOf('"type": 8') !== -1)) {
                                    var p = JSON.parse(data);
                                    if (p && p.type === 8 && Array.isArray(p.source)) {
                                        var activeAcc = null;
                                        if (typeof sys !== "undefined" && sys.localStorage) {
                                            activeAcc = sys.localStorage.getItem("nh_active_account");
                                        }
                                        if (!activeAcc && typeof accountUtil !== "undefined" && accountUtil.getAccount) {
                                            activeAcc = accountUtil.getAccount();
                                        }
                                        if (activeAcc) {
                                            p.source[0] = String(activeAcc).trim();
                                            data = JSON.stringify(p);
                                            if (typeof cc !== "undefined" && cc.log) {
                                                cc.log("[NH Session] Injected active account into login packet: " + activeAcc);
                                            }
                                        }
                                    }
                                }
                            } catch(eSendHook) {}
                            return _origSessSend.call(this, data);
                        };
                    }
                    return sess;
                };
            }
        } catch (eNadHook) {}
    } catch (eRoleGuard) {
        if (typeof cc !== "undefined" && cc.log) cc.log("[NH Error] eRoleGuard: " + eRoleGuard);
    }

    // 2b. Neutralize TalkingData analytics & AppsFlyer native JNI bridges immediately
    try {
        if (typeof jsbTools !== "undefined" && jsbTools) {
            jsbTools.onCommonEvent = _nhNoop;
            jsbTools.onTalkingDataStart = _nhNoop;
        }
        if (typeof talkingData !== "undefined" && talkingData) {
            talkingData.loading = _nhNoop;
            talkingData.guideStep = _nhNoop;
            talkingData.commonEvent = _nhNoop;
            talkingData.onCustomerEvent = _nhNoop;
        }
        if (typeof channelBinding !== "undefined" && channelBinding) {
            channelBinding.appsFlyerEvent = _nhNoop;
        }
        if (typeof ts !== "undefined" && ts && ts.ChannelBinding && ts.ChannelBinding.prototype) {
            ts.ChannelBinding.prototype.appsFlyerEvent = _nhNoop;
        }
    } catch (eJNI) {}


    // 2d. Hook nad.sessionFactory, accountUtil, and serverUtil for seamless game entry
    try {
        if (typeof nad !== "undefined" && nad && nad.sessionFactory) {
            var _origSessionFactory = nad.sessionFactory;
            nad.sessionFactory = function () {
                var args = Array.prototype.slice.call(arguments);
                // Cocos2d-x libwebsockets requires explicit port :80 to prevent connection failure
                args[0] = "ws://nh.digislams.my.id:80/nadsocket";
                if (typeof cc !== "undefined" && cc.log) {
                    cc.log("[NH nad.sessionFactory] connecting to " + args[0]);
                }
                return _origSessionFactory.apply(this, args);
            };
        }
    } catch (eNad) {}

    try {
        if (typeof accountUtil !== "undefined" && accountUtil) {
            accountUtil.getRealServerIp = function () {
                return "nh.digislams.my.id";
            };
        }
        if (typeof serverUtil !== "undefined" && serverUtil) {
            serverUtil.getLastServerIp = function () {
                return "nh.digislams.my.id";
            };
        }
    } catch (eUtil) {}

    // 2c. Safeguard httpUtil notice to prevent DNS timeout on undefined host & dead ports 9001/9002
    try {
        if (typeof httpUtil !== "undefined" && httpUtil) {
            httpUtil.sendNoticeHttp = function () {
                // Disabled at boot to bypass Tsunade modal and eliminate DNS/port 9001 hang
            };
        }
        if (typeof PromptLayer !== "undefined") {
            if (PromptLayer.prototype && PromptLayer.prototype.setPageView) {
                var _origProtoSetPageView = PromptLayer.prototype.setPageView;
                PromptLayer.prototype.setPageView = function (viewName) {
                    if (viewName === "GameNotice") {
                        return;
                    }
                    return _origProtoSetPageView.apply(this, arguments);
                };
            }
            if (PromptLayer.setPageView) {
                var _origStaticSetPageView = PromptLayer.setPageView;
                PromptLayer.setPageView = function (viewName) {
                    if (viewName === "GameNotice") {
                        return;
                    }
                    return _origStaticSetPageView.apply(this, arguments);
                };
            }
        }
        if (typeof GameNotice !== "undefined" && GameNotice.prototype) {
            GameNotice.prototype.initUI = function () {
                if (this.removeFromParent) {
                    this.removeFromParent();
                }
            };
        }
    } catch (eHttp) {}

    // 2d. Eliminate startup 30s hang: bypass dead port 9001/9002 checkClientVersion
    try {
        if (typeof httpUtil !== "undefined" && httpUtil) {
            httpUtil.checkClientVersion = function (a) {
                var scene = (httpUtil.getLoginScene && httpUtil.getLoginScene()) || (typeof LoginScene !== "undefined" && LoginScene.prototype);
                if (scene && scene.startInitUI) {
                    scene.startInitUI(a);
                }
            };
        }
        if (typeof LoginScene !== "undefined" && LoginScene.prototype) {
            var _origLoginInitUI = LoginScene.prototype.initUI;
            LoginScene.prototype.initUI = function (a) {
                if (typeof httpUtil !== "undefined" && httpUtil && httpUtil.resetSender) {
                    httpUtil.resetSender(this);
                }
                this.lastRequest = this.initUI;
                if (this.startInitUI) {
                    this.startInitUI(a);
                } else if (_origLoginInitUI) {
                    _origLoginInitUI.apply(this, arguments);
                }
            };
        }
    } catch (eCheckVer) {}

    // 3. Ninja menu (ZhuangBeiScene) fix: ensure costumeContainer is hidden by default
    try {
        if (typeof ZhuangBeiScene !== "undefined" && ZhuangBeiScene.prototype) {
            var _origInitUI = ZhuangBeiScene.prototype.initUI;
            ZhuangBeiScene.prototype.initUI = function () {
                var res = _origInitUI ? _origInitUI.apply(this, arguments) : undefined;
                try {
                    if (this.costumeContainer) {
                        this.costumeContainer.setVisible(false);
                    }
                    if (this.roleContainer) {
                        this.roleContainer.setVisible(true);
                    }
                } catch (eInit) {}
                return res;
            };
        }
    } catch (eNinja) {}

    // 4. Village & Player Rename: Activate rename controls guarded by UserData.isJointed
    try {
        if (typeof UserData !== "undefined" && UserData.prototype) {
            UserData.prototype.isJointed = function () {
                return true;
            };
            if (UserData.getInstance) {
                var _origGetInstance = UserData.getInstance;
                UserData.getInstance = function () {
                    var inst = _origGetInstance.apply(this, arguments);
                    if (inst) {
                        inst.isJoint = 1;
                    }
                    return inst;
                };
            }
        }
    } catch (eJoint) {}

    // 5. Ninja Storage Expansion Box name normalization (Double-Sided Guard)
    try {
        var applyStorageNames = function () {
            if (typeof JsonData !== "undefined" && JsonData && JsonData.Item) {
                for (var i = 0; i < JsonData.Item.length; i++) {
                    var it = JsonData.Item[i];
                    if (it.id === 5000) {
                        it.alt = "Ninja Storage +5";
                        it.tip = "Ninja storage +5 slots!";
                    } else if (it.id === 5066) {
                        it.alt = "Ninja Storage +10";
                        it.tip = "Upgrade storage +10 slots! Max capacity 500.";
                    }
                }
            }
            if (typeof Config !== "undefined" && Config.getInstance) {
                var cfg = Config.getInstance();
                if (cfg && cfg.itemObject) {
                    if (cfg.itemObject[5000]) {
                        cfg.itemObject[5000].alt = "Ninja Storage +5";
                        cfg.itemObject[5000].tip = "Ninja storage +5 slots!";
                    }
                    if (cfg.itemObject[5066]) {
                        cfg.itemObject[5066].alt = "Ninja Storage +10";
                        cfg.itemObject[5066].tip = "Upgrade storage +10 slots! Max capacity 500.";
                    }
                }
            }
        };

        applyStorageNames();

        if (typeof Config !== "undefined" && Config.prototype && Config.prototype.processItem) {
            var _origProcessItem = Config.prototype.processItem;
            Config.prototype.processItem = function () {
                var res = _origProcessItem.apply(this, arguments);
                try {
                    applyStorageNames();
                } catch (eProc) {}
                return res;
            };
        }
    } catch (eStorage) {}

    // 6. Load Silver Recharge & Custom In-Game Features (Self-Contained & Lean)
    try {
        try {
            require("UI/custom/recharge_silver.js");
        } catch (err3) {
            require("custom/recharge_silver.js");
        }
    } catch (e3) {
        if (typeof cc !== "undefined" && cc.log) cc.log("[main.js] Error loading recharge_silver: " + e3);
    }

    // 7. Load Special Claw Crane (SCC) Custom Guarantee UR Selection
    try {
        try {
            require("UI/custom/scc_guarantee.js");
        } catch (err4) {
            require("custom/scc_guarantee.js");
        }
    } catch (e4) {
        if (typeof cc !== "undefined" && cc.log) cc.log("[main.js] Error loading scc_guarantee: " + e4);
    }

    // 8. Load Batch Combine & Soul Fusion with Grade Filter and Search
    try {
        try {
            require("UI/custom/lab_batch_fusion.js");
        } catch (err5) {
            require("custom/lab_batch_fusion.js");
        }
    } catch (e5) {
        if (typeof cc !== "undefined" && cc.log) cc.log("[main.js] Error loading lab_batch_fusion: " + e5);
    }
})();
