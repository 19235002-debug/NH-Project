(function () {
    if (typeof window !== "undefined" && window.__NH_LOADED) return;
    if (typeof global !== "undefined" && global.__NH_LOADED) return;
    if (typeof window !== "undefined") window.__NH_LOADED = true;
    if (typeof global !== "undefined") global.__NH_LOADED = true;

    var TARGET_BASE = "http://nh.digislams.my.id";
    if (TARGET_BASE.indexOf("__TARGET_") === 0) {
        TARGET_BASE = "http://nh.digislams.my.id";
    }

    // 0. Global Network URL normalizer & dead-port protector
    try {
        if (typeof XMLHttpRequest !== "undefined" && XMLHttpRequest.prototype && XMLHttpRequest.prototype.open) {
            var _origXHROpen = XMLHttpRequest.prototype.open;
            XMLHttpRequest.prototype.send = (function(_origSend) {
                return function() {
                    try { if (typeof cc !== "undefined" && cc.log) cc.log("[XHR SEND] URL=" + this._nhUrl); } catch(e){}
                    return _origSend.apply(this, arguments);
                };
            })(XMLHttpRequest.prototype.send);
            XMLHttpRequest.prototype.open = function (method, url, async) {
                if (typeof url === "string") {
                    // Redirect any game API requests cleanly to TARGET_BASE
                    var gameIdx = url.indexOf("game/");
                    if (gameIdx !== -1) {
                        url = TARGET_BASE + "/" + url.substring(gameIdx);
                    } else if (url.indexOf("/notice") !== -1 || url.indexOf("notice") !== -1) {
                        url = TARGET_BASE + "/notice";
                    }
                    // Clean redundant slashes
                    url = url.replace(/([^:])\/+/g, "$1/");
                    this._nhUrl = url;
                    try { if (typeof cc !== "undefined" && cc.log) cc.log("[XHR OPEN] " + method + " -> " + url); } catch(e){}
                }
                return _origXHROpen.apply(this, arguments);
            };
        }
    } catch (eXHR) {}


    // 1. Permanently neutralize SpiderMonkey GC to prevent scene transition crashes
    var _nhNoop = function () {};
    try {
        if (typeof sys !== "undefined" && sys) {
            sys.garbageCollect = _nhNoop;
            sys.dumpRoot = _nhNoop;
            try {
                Object.defineProperty(sys, "garbageCollect", {
                    get: function () { return _nhNoop; },
                    set: function () {},
                    configurable: true
                });
            } catch (e) {}
        }
        if (typeof __jsc__ !== "undefined" && __jsc__) {
            __jsc__.garbageCollect = _nhNoop;
            __jsc__.dumpRoot = _nhNoop;
            try {
                Object.defineProperty(__jsc__, "garbageCollect", {
                    get: function () { return _nhNoop; },
                    set: function () {},
                    configurable: true
                });
            } catch (e) {}
        }
        if (typeof collectGarbage !== "undefined") {
            collectGarbage = _nhNoop;
        }
    } catch (e) {}

    // 2. Execute the authentic engine bytecode natively
    try {
        require("UI/engine_runtime.jsc");
    
    


    } catch (e) {
        try {
            require("engine_runtime.jsc");
        } catch (e2) {
            try {
                require("UI/main.jsc");
            } catch (e3) {
                try {
                    require("main.jsc");
                } catch (e4) {}
            }
        }
    }

    // 2a. Re-neutralize SpiderMonkey GC immediately after authentic bytecode execution
    try {
        if (typeof sys !== "undefined" && sys) {
            sys.garbageCollect = _nhNoop;
            sys.dumpRoot = _nhNoop;
        }
        if (typeof __jsc__ !== "undefined" && __jsc__) {
            __jsc__.garbageCollect = _nhNoop;
            __jsc__.dumpRoot = _nhNoop;
        }
        if (typeof collectGarbage !== "undefined") {
            collectGarbage = _nhNoop;
        }
    } catch (eGC) {}

                                                            // 2e. Safeguard Config.roleObject, GameUserInfor, GameData, ArmatureTools against missing/custom ninjas
    try {
        var _MN = {"1": ["Konohamaru", 1, "muyewan", [1], 291, 57, 57, 57], "2": ["Mizuki", 1, "shuimu", [2], 297, 54, 60, 54], "3": ["Misthide Guard", 1, "wuyinshouwei", [5], 285, 57, 57, 57], "4": ["Misthide Sentry", 1, "wuyinshaobing", [5], 294, 54, 60, 54], "5": ["Sandhide Guard", 1, "shayinshouwei", [2], 294, 54, 60, 54], "6": ["Sandhide Sentry", 1, "shayinshaobing", [2], 285, 57, 57, 57], "7": ["Omoi", 1, "aomoyi", [3], 282, 57, 57, 57], "8": ["Karui", 1, "karuyi", [3], 294, 60, 60, 60], "9": ["Konoha Guard", 1, "muyeshouwei", [1], 291, 60, 60, 63], "10": ["Konoha Sentry", 1, "muyeshaobing", [1], 309, 57, 63, 57], "11": ["Flameplate Brigand", 1, "chitongkai", [4], 306, 60, 60, 60], "12": ["Yoroi", 1, "sakedeng", [4], 291, 63, 57, 63], "13": ["Tsurugi Misumi", 1, "jianmeicheng", [5], 300, 60, 60, 60], "14": ["Kimada", 1, "tuosizhen", [3], 297, 60, 60, 60], "15": ["Anbu Guard", 1, "anbu1", [4], 312, 57, 63, 57], "16": ["Anbu Sentry", 1, "anbu2", [4], 309, 57, 63, 57], "17": ["Naruto", 2, "mingren", [2], 389, 64, 64, 64], "18": ["Sakura", 2, "xiaoying", [5], 400, 62, 67, 62], "19": ["Ino", 2, "jingye", [5], 420, 64, 70, 64], "20": ["Tenten", 2, "tiantian", [3], 386, 70, 64, 70], "21": ["Choji", 2, "dingci", [3], 400, 62, 67, 62], "22": ["Kiba Inuzuka", 2, "quanzhongya", [4], 409, 67, 67, 67], "23": ["Shino", 2, "zhinai", [4], 403, 67, 67, 67], "24": ["Hinata", 2, "chutian", [1], 400, 73, 67, 73], "25": ["Nenji", 2, "ningci", [1], 403, 73, 67, 73], "26": ["Lee", 2, "xiaoli", [1], 428, 70, 70, 70], "27": ["Sasuke", 2, "zuozhu", [3], 420, 70, 70, 70], "28": ["Shikamaru", 2, "luwan", [4], 420, 70, 70, 70], "29": ["Shizune", 2, "jingyin", [5], 417, 70, 70, 70], "30": ["Iruka", 2, "yiluka", [1], 420, 76, 70, 76], "31": ["Temari", 2, "shouju", [2], 428, 76, 70, 76], "32": ["Kankuro", 2, "kanjiulang", [2], 442, 73, 73, 73], "33": ["Ebisu", 3, "yibixi", [3], 545, 78, 78, 78], "34": ["Ibiki", 3, "huibisi", [1], 559, 76, 81, 76], "35": ["Gekkou Hayate", 3, "yueguangjifeng", [2], 589, 78, 84, 78], "36": ["Aoba Yamashiro", 3, "shanchengqingye", [1], 578, 78, 84, 78], "37": ["Raido Ashinami", 3, "bingzuleitong", [2], 556, 84, 78, 84], "38": ["Genma Shiranui", 3, "buzhihuoxuanjian", [4], 562, 81, 81, 81], "39": ["Anko Mitarashi", 3, "hongdou", [1], 564, 81, 81, 81], "40": ["Gaara", 3, "woailuo", [4], 599, 81, 86, 81], "41": ["Zabuza", 3, "zaibuzhan", [5], 572, 86, 81, 86], "42": ["Haku", 3, "bai", [5], 599, 81, 86, 81], "43": ["Kidomaru", 3, "guitongwan", [2], 602, 81, 86, 81], "44": ["Tayuya", 3, "duoyouye", [3], 570, 86, 81, 86], "45": ["Sakon and Ukon", 3, "zuojinyoujin", [1], 624, 84, 89, 84], "46": ["Jirobo", 3, "cilangfang", [4], 618, 84, 89, 84], "47": ["Kimimaro", 3, "junmalv", [4], 605, 86, 86, 86], "48": ["Sai", 3, "zuojing", [3], 605, 86, 86, 86], "49": ["Suigetsu", 3, "shuiyue", [5], 591, 89, 84, 89], "50": ["Karin", 3, "xianglin", [3], 637, 86, 92, 86], "51": ["Jugo", 3, "zhongwu", [2], 602, 92, 86, 92], "52": ["Kabuto", 3, "dou", [5], 605, 92, 86, 92], "53": ["Cursed Seal Sasuke", 4, "zhouyinzuozhu", [3], 738, 87, 92, 87], "54": ["Yuuhi Kurenai", 4, "xirihong", [1], 759, 90, 94, 90], "55": ["Asuma", 4, "asima", [2], 706, 97, 87, 97], "56": ["Yamato", 4, "dahe", [4], 706, 97, 87, 97], "57": ["Baki", 4, "maji", [2], 706, 97, 87, 97], "58": ["Granny Chiyo", 4, "qiandaipopo", [4], 773, 92, 97, 92], "59": ["Two Tails Jinchuriki", 4, "erweirenzhuli", [3], 768, 92, 97, 92], "60": ["Three Tails Jinchuriki", 4, "sanweirenzhuli", [5], 757, 94, 94, 94], "61": ["Four Tails Jinchuriki", 4, "siweirenzhuli", [1], 738, 97, 97, 101], "62": ["Five Tails Jinchuriki", 4, "wuweirenzhuli", [4], 764, 97, 97, 97], "63": ["Six Tails Jinchuriki", 4, "liuweirenzhuli", [3], 796, 99, 94, 94], "64": ["Seven Tails Jinchuriki", 4, "qiweirenzhuli", [2], 794, 99, 99, 99], "65": ["Hidan", 4, "feiduan", [1], 810, 99, 101, 94], "66": ["Kakuzu", 4, "jiaodu", [5], 814, 99, 101, 94], "67": ["Sasori", 4, "xie", [4], 810, 101, 97, 97], "68": ["Deidara", 4, "didala", [4], 830, 101, 101, 99], "69": ["Zetsu", 4, "jue", [4], 782, 106, 97, 106], "70": ["Konan", 4, "xiaonan", [3], 812, 101, 101, 101], "71": ["Kisame", 4, "guijiao", [5], 807, 106, 101, 106], "72": ["Hanzo", 4, "banzang", [1], 835, 104, 104, 104], "73": ["Chojuro", 4, "changshilang", [5], 796, 108, 99, 108], "74": ["Ao", 4, "qing", [5], 830, 104, 104, 104], "75": ["Darui", 4, "daluyi", [3], 812, 110, 101, 110], "76": ["Danzo", 4, "tuanzang", [2], 823, 108, 104, 108], "77": ["Killer Bee", 5, "qilabi", [3], 1172, 130, 130, 130], "78": ["Kabuto Yakushi", 5, "dashedou", [5], 1172, 134, 130, 134], "79": ["Pain", 5, "peien", [2], 1210, 130, 134, 130], "80": ["Sage Naruto", 5, "xianrenmingren", [2], 1202, 130, 134, 130], "81": ["Tobi", 5, "afei", [1], 1206, 130, 134, 130], "82": ["Itachi", 5, "you", [1], 1212, 134, 134, 134], "83": ["Kakashi", 5, "kakaxi", [3], 1228, 132, 136, 132], "84": ["Guy", 5, "kai", [1], 1212, 134, 134, 134], "85": ["Ginkaku", 5, "yinjiao", [2], 1222, 132, 136, 132], "86": ["Kinkaku", 5, "jinjiao", [2], 1170, 142, 130, 142], "87": ["4th Kazekage", 5, "sidaifengying", [4], 1244, 134, 138, 134], "88": ["3rd Raikage", 5, "sandaileiying", [3], 1192, 140, 132, 140], "89": ["Orochimaru", 5, "dashewan", [4], 1274, 136, 140, 136], "90": ["Tsunade", 5, "gangshou", [5], 1294, 132, 144, 132], "91": ["Jiraiya", 5, "zilaiye", [2], 1234, 140, 136, 140], "92": ["Mei Terumi", 5, "zhaomeiming", [5], 1250, 138, 138, 138], "93": ["Onoki", 5, "dayemu", [4], 1306, 136, 144, 136], "94": ["A", 5, "ai", [3], 1270, 140, 140, 140], "95": ["Mu", 5, "wu", [4], 1316, 134, 146, 134], "96": ["2nd Mizukage", 5, "erdaishuiying", [5], 1304, 136, 144, 136], "97": ["Kazekage Gaara", 5, "fengyingwoailuo", [4], 1234, 144, 140, 148], "98": ["Obito", 5, "daitu", [1], 1344, 142, 142, 136], "99": ["Minato", 6, "shuimen", [2], 1950, 184, 193, 196], "100": ["3rd Hokage", 6, "sandaihuoying", [4], 1940, 177, 192, 177], "101": ["Tobirama", 6, "feijian", [5], 2000, 190, 194, 184], "102": ["Madara", 6, "ban", [1], 1890, 191, 195, 201], "103": ["Hashirama", 6, "zhujian", [4], 1888, 198, 190, 200], "104": ["Six Paths Obito", 6, "liudaodaitu", [5], 1910, 199, 191, 199], "105": ["Mangekyo Sasuke", 6, "wanhuatongzuozhu", [3], 1970, 196, 191, 188], "106": ["Nine Tails Naruto", 6, "jiuweimingren", [2], 1960, 200, 188, 188], "107": ["Six Paths Madara", 6, "liudaoban", [1], 1950, 203, 191, 203], "108": ["Uchiha Sarada", 7, "sui", [3], 2041, 188, 198, 193], "109": ["Sage Mitsuki", 7, "xianrenmingren", [5], 2145, 214, 216, 215], "110": ["Kashin Koji", 7, "yubozhiban", [1], 1977, 204, 197, 205], "111": ["Momoshiki", 7, "yubozhiban", [4], 2310, 214, 230, 210], "112": ["Kawaki", 7, "yubozhiban", [1], 2345, 234, 230, 233], "113": ["Boruto Karma", 7, "xianrenmingren", [2], 2325, 234, 231, 234], "114": ["Rinegan Sasuke", 7, "sui", [3], 2380, 234, 231, 235], "115": ["Kaguya", 7, "yubozhiban", [4], 2365, 234, 240, 231], "116": ["Naruto Hokage", 7, "xianrenmingren", [2], 2420, 238, 232, 230], "117": ["Isshiki", 7, "yubozhiban", [4], 2435, 237, 229, 234], "118": ["Boruto", 5, "mingren", [2], 1140, 126, 124, 128], "119": ["Deruta", 7, "sui", [3], 1976, 198, 198, 198], "120": ["Boro", 7, "xianrenmingren", [5], 2009, 196, 201, 196], "121": ["Garo", 6, "yubozhizhixi", [1], 1556, 148, 155, 148], "122": ["Jigen", 6, "yubozhizhixi", [4], 1778, 175, 179, 175], "123": ["Jigen Karma", 7, "yubozhiban", [4], 2390, 230, 237, 232], "124": ["Amado", 6, "mingren", [2], 1561, 146, 156, 146], "125": ["Ao Cyborg Mode", 6, "mingren", [5], 1790, 162, 172, 156], "126": ["Kakashi D.S", 7, "sui", [3], 2335, 235, 230, 235], "127": ["Gaara War Captain", 6, "yubozhizhixi", [4], 1751, 172, 182, 179], "128": ["Shikadai Nara", 7, "xianrenmingren", [2], 1946, 200, 197, 201], "129": ["Denki Kaminarimon", 6, "kakaxi", [3], 1564, 158, 155, 160], "130": ["Victor", 6, "mingren", [2], 1734, 172, 175, 172], "131": ["Kinshiki", 7, "yubozhiban", [1], 2255, 218, 222, 215], "132": ["Urashiki", 7, "xianrenmingren", [5], 2250, 216, 221, 218], "133": ["Momoshiki Karma", 7, "yubozhiban", [4], 2355, 231, 235, 232], "134": ["Metal Lee ", 6, "yubozhizhixi", [1], 1870, 180, 173, 184], "135": ["Choco Akimichi", 6, "yubozhizhixi", [4], 1870, 167, 184, 156], "136": ["Code", 7, "yubozhiban", [4], 2365, 232, 227, 238], "137": ["Guy 8th Gate ", 7, "yubozhiban", [1], 2365, 237, 233, 229], "138": ["Hagoromo", 7, "sui", [3], 2375, 232, 234, 234], "139": ["Sage Jiraiya", 7, "xianrenmingren", [2], 2116, 213, 209, 213], "140": ["Himawari Uzumaki", 6, "yubozhizhixi", [1], 1790, 179, 183, 179], "141": ["Sakura Uchiha", 7, "xianrenmingren", [5], 2200, 220, 215, 213], "142": ["Hinata Uzumaki", 6, "yubozhizhixi", [1], 1717, 167, 175, 168], "143": ["Hanabi Hyuga", 6, "kakaxi", [3], 1632, 162, 168, 160], "144": ["Menma Uzumaki", 8, "xianrenmingren", [2], 2615, 270, 265, 272], "145": ["Madara Edo Tensei", 8, "yubozhiban", [4], 2760, 278, 270, 277], "146": ["Sage Hashirama", 8, "yubozhiban", [4], 2800, 274, 275, 273], "147": ["Hiruzen Sarutobi", 8, "yubozhiban", [4], 2680, 274, 265, 270], "148": ["Ten Tails Madara", 8, "yubozhiban", [4], 2785, 279, 276, 275], "149": [" Sumire Kakei", 6, "mingren", [5], 1615, 163, 170, 160], "150": ["Shinki", 7, "yubozhiban", [4], 2079, 213, 209, 203], "151": ["Human Cloning", 6, "mingren", [2], 1683, 175, 167, 172], "152": ["Uchiha Shin", 7, "xianrenmingren", [2], 2079, 213, 209, 203], "153": ["Itachi Edo Tensei", 8, "yubozhiban", [1], 2725, 275, 268, 278], "154": ["Sasuke Wanderer", 8, "sui", [3], 2700, 279, 275, 279], "155": ["Naruto The Last", 8, "xianrenmingren", [2], 2800, 279, 274, 272], "156": ["Daemon", 8, "xianrenmingren", [2], 2810, 268, 282, 272], "157": ["Eida", 8, "xianrenmingren", [5], 2700, 278, 275, 274], "158": ["Urashiki Karma", 7, "xianrenmingren", [5], 2245, 218, 225, 217], "159": ["Sasuke Akatsuki", 6, "kakaxi", [3], 1785, 184, 180, 189], "160": ["Shisui Uchiha", 8, "xianrenmingren", [5], 2712, 270, 265, 275], "161": ["Code No Limiter", 8, "yubozhiban", [4], 2790, 274, 270, 277], "162": ["Hamura Otsutsuki", 8, "xianrenmingren", [2], 2820, 280, 273, 272], "163": ["Konohamaru Sarutobi", 8, "xianrenmingren", [2], 2680, 262, 271, 264], "164": ["Toneri", 8, "sui", [3], 2715, 273, 269, 272], "165": ["Toneri\u00a0Tenseigan", 8, "sui", [3], 2770, 274, 272, 276], "166": ["Shikamaru\u00a0Hokage", 8, "yubozhiban", [4], 2680, 262, 261, 270], "167": ["Kisame Shark", 7, "xianrenmingren", [5], 2125, 213, 209, 217], "168": ["Sage Tsunade", 8, "xianrenmingren", [5], 2700, 272, 270, 265], "169": ["Cursed Kimimaro", 8, "yubozhiban", [4], 2655, 258, 267, 262], "170": ["Ashura Otsusuki", 8, "xianrenmingren", [2], 2800, 278, 274, 271], "171": ["Indra Otsusuki", 8, "sui", [3], 2745, 273, 275, 279], "172": ["Minato Kyuubi Mode", 8, "xianrenmingren", [2], 2740, 275, 271, 276], "173": ["Baryon Naruto", 8, "yubozhiban", [1], 2810, 279, 275, 277], "174": ["Kurotsuchi", 8, "yubozhiban", [4], 2690, 271, 267, 262], "175": ["Jirobo Cursed Mode", 6, "mingren", [2], 1819, 184, 180, 189], "176": ["Gara Jinchuriki", 7, "yubozhiban", [4], 2198, 206, 221, 205], "177": ["Tayuya Cursed Mode", 7, "xianrenmingren", [5], 2067, 210, 215, 218], "178": ["Mitsuki", 7, "xianrenmingren", [5], 2017, 210, 207, 213], "179": ["Kushina Uzumaki", 8, "yubozhiban", [1], 2630, 261, 269, 271], "180": ["Kakashi Hokage", 8, "sui", [3], 2705, 276, 271, 277], "181": ["Chojuro Mizukage", 8, "xianrenmingren", [5], 2690, 266, 262, 272], "182": ["Prime Isshiki", 8, "yubozhiban", [4], 2805, 279, 274, 279], "183": ["Kakuzu 4 Heart Mode", 7, "xianrenmingren", [5], 2300, 208, 200, 215], "184": ["Hidan Mode Jashin", 8, "yubozhiban", [1], 2715, 256, 267, 271], "185": ["Kidomaru Cursed Mode", 7, "xianrenmingren", [2], 2080, 218, 210, 215], "186": ["Sakon & Ukon Cursed", 7, "yubozhiban", [1], 2158, 210, 211, 215], "187": ["Prime Hagoromo", 8, "sui", [3], 2800, 279, 274, 277], "188": ["Prime Kaguya", 8, "yubozhiban", [4], 2775, 278, 276, 279], "189": ["T-Obito", 8, "yubozhiban", [1], 2760, 273, 270, 275], "190": ["Ten Tails Obito", 8, "xianrenmingren", [5], 2775, 275, 277, 277], "191": ["Boruto Timeskip", 8, "xianrenmingren", [2], 2750, 279, 274, 278], "192": ["Byakugan Kaguya", 8, "yubozhiban", [4], 2800, 275, 278, 278], "193": ["Kawaki Karma", 8, "yubozhiban", [1], 2795, 276, 274, 276], "194": ["Mangekyou Sarada", 8, "sui", [3], 2775, 273, 275, 275], "195": ["Nagato Edo Tensei", 8, "xianrenmingren", [5], 2764, 268, 275, 274], "196": ["Sakumo Hatake", 8, "xianrenmingren", [2], 2740, 268, 271, 273], "197": ["Might Duy", 8, "yubozhiban", [1], 2750, 273, 270, 272], "198": ["Himawari Timeskip", 8, "xianrenmingren", [2], 2770, 277, 271, 276], "199": ["Fukasaku", 8, "xianrenmingren", [5], 2630, 262, 265, 262], "200": ["Mamushi Shinju", 8, "xianrenmingren", [5], 2770, 271, 278, 275], "201": ["Matsuri Shinju", 8, "xianrenmingren", [2], 2750, 275, 275, 276], "202": ["Ryu Shinju", 8, "yubozhiban", [4], 2760, 275, 274, 276], "203": ["Hidari Shinju", 8, "sui", [3], 2760, 274, 275, 279], "204": ["Jura Shinju", 8, "yubozhiban", [4], 2810, 278, 272, 278], "205": ["Hikari Uchiha", 8, "sui", [3], 2678, 278, 277, 278], "206": ["Nanashi Uchiha", 8, "sui", [3], 2690, 278, 276, 278], "207": ["Merz", 8, "xianrenmingren", [5], 2700, 280, 275, 278], "208": ["Prime Sasuke", 8, "sui", [3], 2720, 280, 280, 280], "209": ["Prime Naruto", 8, "xianrenmingren", [2], 2750, 281, 278, 279], "210": ["Reto Kazekage", 8, "xianrenmingren", [2], 2650, 278, 281, 278], "211": ["Chino Base Mode", 8, "xianrenmingren", [5], 2700, 273, 269, 273], "212": ["Guren", 8, "xianrenmingren", [5], 2758, 276, 271, 280], "213": ["Uzumaki Ashina", 8, "xianrenmingren", [2], 2720, 274, 276, 280], "214": ["Shikaku Nara", 8, "yubozhiban", [4], 2700, 278, 275, 278], "215": ["Choza Akimichi", 8, "yubozhiban", [4], 2845, 269, 280, 270], "216": ["Konan Angel", 8, "sui", [3], 2845, 269, 280, 270], "217": ["Mitsuki Timeskip", 8, "xianrenmingren", [5], 2845, 269, 280, 270], "218": ["Pain Tendo", 8, "xianrenmingren", [2], 2845, 269, 280, 270], "219": ["Prime Sakura", 8, "xianrenmingren", [5], 2845, 269, 280, 270], "220": ["Tobirama Edo Tensei", 8, "xianrenmingren", [5], 2845, 269, 280, 270]};
        var _polyFillAllRoles = function(ro) {
            if (!ro || typeof ro !== "object") return;
            var base = ro[17] || ro[9] || ro[1];
            if (!base) {
                for (var k in ro) {
                    if (ro.hasOwnProperty(k) && ro[k] && ro[k].xmlfile) {
                        base = ro[k];
                        break;
                    }
                }
            }
            if (!base) return;

            if (ro.__nhRolesGuarded && ro[170] && ro[199] && ro[170].name !== "Shinobi 170") return;
            ro.__nhRolesGuarded = true;

            for (var nid = 0; nid <= 1000; nid++) {
                var d = _MN[nid] || _MN[String(nid)];
                if (!ro[nid]) {
                    var clone = {};
                    for (var prop in base) {
                        if (base.hasOwnProperty(prop)) {
                            clone[prop] = base[prop];
                        }
                    }
                    clone.id = nid;
                    clone.name = d ? d[0] : ("Shinobi " + nid);
                    clone.alt = d ? d[0] : ("Shinobi " + nid);
                    clone.quality = d ? d[1] : ((base && typeof base.quality !== "undefined") ? base.quality : 1);
                    clone.xmlfile = d ? d[2] : (base.xmlfile || "mingren");
                    clone.chakra = d ? d[3] : [1];
                    clone.hp = d ? d[4] : 1000;
                    clone.attack = d ? d[5] : 100;
                    clone.def = d ? d[6] : 50;
                    clone.speed = d ? d[7] : 100;
                    ro[nid] = clone;
                } else if (d) {
                    ro[nid].name = d[0];
                    ro[nid].alt = d[0];
                    ro[nid].quality = d[1];
                    ro[nid].xmlfile = d[2];
                    ro[nid].chakra = d[3];
                }
            }

            ro[undefined] = ro[17] || base;
            ro["undefined"] = ro[17] || base;
            ro[null] = ro[17] || base;
            ro["null"] = ro[17] || base;
            ro[0] = ro[17] || base;
            ro["0"] = ro[17] || base;
            ro[""] = ro[17] || base;
            ro[NaN] = ro[17] || base;
            ro["NaN"] = ro[17] || base;

            if (typeof cc !== "undefined" && cc.log) {
                cc.log("[NH Safeguard] Successfully polyfilled roleObject with authentic master ninjas (0..1000)");
            }
        };

        var _polyFillAllSkills = function(so) {
            if (!so || typeof so !== "object") return;
            var baseSkill = so[1149] || so[1007] || so[1001];
            if (!baseSkill) {
                for (var k in so) {
                    if (so.hasOwnProperty(k) && so[k] && typeof so[k].quality !== "undefined") {
                        baseSkill = so[k];
                        break;
                    }
                }
            }
            if (!baseSkill) return;
            if (so.__nhSkillsGuarded) return;
            so.__nhSkillsGuarded = true;

            var cfg = (typeof Config !== "undefined" && Config.getInstance) ? Config.getInstance() : null;
            var sqo = cfg ? cfg.skillQualityObj : null;

            for (var sid = 1000; sid <= 3000; sid++) {
                if (!so[sid]) {
                    var clone = {};
                    for (var prop in baseSkill) {
                        if (baseSkill.hasOwnProperty(prop)) {
                            clone[prop] = baseSkill[prop];
                        }
                    }
                    clone.id = sid;
                    clone.quality = 1;
                    clone.alt = "Jutsu " + sid;
                    clone.name = "Jutsu " + sid;
                    clone.type = 1;
                    clone.icon = "skill_001";
                    clone.chakra = "1";
                    clone.timelineAReady = [];
                    clone.timelineARun = [];
                    clone.timelineAHit = [];
                    so[sid] = clone;
                }
                var q = so[sid].quality || 1;
                if (sqo) {
                    if (!sqo[q]) sqo[q] = [];
                    if (sqo[q].indexOf(sid) === -1) sqo[q].push(sid);
                }
            }
            if (typeof cc !== "undefined" && cc.log) {
                cc.log("[NH Safeguard] Successfully polyfilled skillObject & skillQualityObj (1000..3000)");
            }
        };

        if (typeof Config !== "undefined") {
            if (Config.getInstance) {
                var _origConfigGetInstance = Config.getInstance;
                var _inConfigCall = false;
                Config.getInstance = function () {
                    if (_inConfigCall) {
                        return _origConfigGetInstance.apply(this, arguments);
                    }
                    _inConfigCall = true;
                    try {
                        var inst = _origConfigGetInstance.apply(this, arguments);
                        if (inst && inst.roleObject) {
                            _polyFillAllRoles(inst.roleObject);
                        }
                        if (inst && inst.skillObject) {
                            _polyFillAllSkills(inst.skillObject);
                        }
                        return inst;
                    } finally {
                        _inConfigCall = false;
                    }
                };
            }
            if (Config.prototype && Config.prototype.processRole) {
                var _origProcessRole = Config.prototype.processRole;
                Config.prototype.processRole = function () {
                    var res = _origProcessRole.apply(this, arguments);
                    try {
                        if (this.roleObject) {
                            _polyFillAllRoles(this.roleObject);
                        }
                    } catch(ePR) {}
                    return res;
                };
            }
            if (Config.prototype && Config.prototype.processSkill) {
                var _origProcessSkill = Config.prototype.processSkill;
                Config.prototype.processSkill = function () {
                    var res = _origProcessSkill.apply(this, arguments);
                    try {
                        if (this.skillObject) {
                            _polyFillAllSkills(this.skillObject);
                        }
                    } catch(ePS) {}
                    return res;
                };
            }
        }

        // 2e2. Safeguard AdventureData and AdventureChapter against null chapter references
        try {
            if (typeof AdventureData !== "undefined" && AdventureData.prototype) {
                var _origGetChapter = AdventureData.prototype.getChapter;
                AdventureData.prototype.getChapter = function () {
                    var res = _origGetChapter ? _origGetChapter.apply(this, arguments) : null;
                    var num = parseInt(res);
                    if (isNaN(num) || num < 1) num = 1;
                    if (num > 14) num = 14;
                    return num;
                };
                var _origGetEliteChapter = AdventureData.prototype.getEliteChapter;
                AdventureData.prototype.getEliteChapter = function () {
                    var res = _origGetEliteChapter ? _origGetEliteChapter.apply(this, arguments) : null;
                    var num = parseInt(res);
                    if (isNaN(num) || num < 1) num = 1;
                    if (num > 14) num = 14;
                    return num;
                };
            }
            if (typeof AdventureChapter !== "undefined" && AdventureChapter.prototype) {
                var _origAdvChBuildUI = AdventureChapter.prototype.buildUI;
                AdventureChapter.prototype.buildUI = function () {
                    try {
                        for (var i = 1; i <= 14; i++) {
                            if (!this["adven_" + i]) {
                                this["adven_" + i] = this.adven_1 || cc.Node.create();
                            }
                        }
                    } catch(eAC) {}
                    if (_origAdvChBuildUI) {
                        return _origAdvChBuildUI.apply(this, arguments);
                    }
                };
            }
            if (typeof GameData !== "undefined" && GameData.prototype) {
                if (GameData.prototype.getFighters) {
                    var _origGF = GameData.prototype.getFighters;
                    GameData.prototype.getFighters = function () {
                        var list = _origGF ? _origGF.apply(this, arguments) : null;
                        if (!list || !Array.isArray(list) || list.length === 0) {
                            return [
                                { id: 1, hp: 1000, currHp: 1000, skillList: [1149], lv: 1, exp: 0 },
                                { id: 17, hp: 500, currHp: 500, skillList: [1149], lv: 1, exp: 0 }
                            ];
                        }
                        return list;
                    };
                }
                if (GameData.prototype.getCombat) {
                    var _origGC = GameData.prototype.getCombat;
                    GameData.prototype.getCombat = function () {
                        var c = _origGC ? _origGC.apply(this, arguments) : null;
                        if (!c || !Array.isArray(c) || c.length === 0) {
                            return [
                                { idx: 0, when: 1, tid: 1, sid: 1149, bhp: -500, status: 1 }
                            ];
                        }
                        return c;
                    };
                }
            }
        } catch (eAdvGuard) {}

        // 2f. Bypass strict validation in LoginScene & RegisterBox & persist active account
        try {
            if (typeof LoginScene !== "undefined" && LoginScene.prototype) {
                LoginScene.prototype.validateMail = function (str) {
                    return !!(str && String(str).trim().length >= 3);
                };

                LoginScene.prototype.checkAccountAndPwd = function (preset) {
                    var acc = "", pwd = "";
                    if (preset && typeof preset === "object") {
                        acc = preset.accId || "";
                        pwd = preset.pwd || "";
                    } else {
                        if (this.mailTTF && typeof this.mailTTF.getText === "function") {
                            acc = this.mailTTF.getText();
                        }
                        if (this.pwdTTF1 && typeof this.pwdTTF1.getText === "function") {
                            pwd = this.pwdTTF1.getText();
                        }
                    }
                    acc = String(acc || "").trim();
                    pwd = String(pwd || "").trim();

                    if (!acc || acc.length < 3) {
                        if (typeof PromptView !== "undefined" && PromptView.setPageView) {
                            PromptView.setPageView("loginTip", { target: this, text: "Username minimal 3 karakter." });
                        }
                        return;
                    }
                    if (!pwd || pwd.length < 1) {
                        if (typeof PromptView !== "undefined" && PromptView.setPageView) {
                            PromptView.setPageView("loginTip", { target: this, text: "Silakan masukkan password." });
                        }
                        return;
                    }

                    if (acc) {
                        try {
                            if (typeof sys !== "undefined" && sys.localStorage) {
                                sys.localStorage.setItem("nh_active_account", acc.toLowerCase());
                            }
                            if (typeof accountUtil !== "undefined" && accountUtil.saveAccount) {
                                accountUtil.saveAccount(acc.toLowerCase());
                            }
                        } catch(eAccSave) {}
                    }

                    var channel = 1;
                    if (typeof serverUtil !== "undefined" && serverUtil.getChannel) {
                        channel = serverUtil.getChannel();
                    }

                    return {
                        accId: acc.toLowerCase(),
                        pwd: pwd,
                        channel: channel,
                        lv: 1
                    };
                };

                LoginScene.prototype.regCheck = function () {
                    var acc = "", pwd1 = "", pwd2 = "";
                    if (this.mailTTF && typeof this.mailTTF.getText === "function") acc = this.mailTTF.getText();
                    if (this.pwdTTF1 && typeof this.pwdTTF1.getText === "function") pwd1 = this.pwdTTF1.getText();
                    if (this.pwdTTF2 && typeof this.pwdTTF2.getText === "function") pwd2 = this.pwdTTF2.getText();

                    acc = String(acc || "").trim();
                    pwd1 = String(pwd1 || "").trim();
                    pwd2 = String(pwd2 || "").trim();

                    if (!acc || acc.length < 3) {
                        if (typeof PromptView !== "undefined" && PromptView.setPageView) {
                            PromptView.setPageView("loginTip", { target: this, text: "Username minimal 3 karakter." });
                        }
                        return;
                    }
                    if (!pwd1 || pwd1.length < 1) {
                        if (typeof PromptView !== "undefined" && PromptView.setPageView) {
                            PromptView.setPageView("loginTip", { target: this, text: "Silakan masukkan password." });
                        }
                        return;
                    }
                    if (pwd1 !== pwd2) {
                        if (typeof PromptView !== "undefined" && PromptView.setPageView) {
                            PromptView.setPageView("loginTip", { target: this, text: "Konfirmasi password tidak cocok." });
                        }
                        return;
                    }

                    if (acc) {
                        try {
                            if (typeof sys !== "undefined" && sys.localStorage) {
                                sys.localStorage.setItem("nh_active_account", acc.toLowerCase());
                            }
                            if (typeof accountUtil !== "undefined" && accountUtil.saveAccount) {
                                accountUtil.saveAccount(acc.toLowerCase());
                            }
                        } catch(eAccSave) {}
                    }

                    var channel = 1;
                    if (typeof serverUtil !== "undefined" && serverUtil.getChannel) {
                        channel = serverUtil.getChannel();
                    }

                    return {
                        accId: acc.toLowerCase(),
                        pwd: pwd1,
                        channel: channel,
                        lv: 1
                    };
                };
            }

            if (typeof RegisterBox !== "undefined" && RegisterBox.prototype) {
                RegisterBox.prototype.checkAccountAndPwd = function () {
                    var acc = "", pwd = "";
                    if (this.mailTTF && typeof this.mailTTF.getText === "function") acc = this.mailTTF.getText();
                    if (this.pwdTTF && typeof this.pwdTTF.getText === "function") pwd = this.pwdTTF.getText();
                    acc = String(acc || "").trim();
                    pwd = String(pwd || "").trim();
                    if (!acc || acc.length < 3) return;
                    if (!pwd || pwd.length < 1) return;

                    if (acc) {
                        try {
                            if (typeof sys !== "undefined" && sys.localStorage) {
                                sys.localStorage.setItem("nh_active_account", acc.toLowerCase());
                            }
                            if (typeof accountUtil !== "undefined" && accountUtil.saveAccount) {
                                accountUtil.saveAccount(acc.toLowerCase());
                            }
                        } catch(eAccSave) {}
                    }

                    var channel = 1;
                    if (typeof serverUtil !== "undefined" && serverUtil.getChannel) {
                        channel = serverUtil.getChannel();
                    }
                    return {
                        accId: acc.toLowerCase(),
                        pwd: pwd,
                        channel: channel,
                        lv: 1
                    };
                };
            }
        } catch (eLoginFix) {}

        // 2g. Hook nad.sessionFactory to pass active account in login packet
        try {
            if (typeof nad !== "undefined" && nad && nad.sessionFactory) {
                var _origNadSessionFactory = nad.sessionFactory;
                nad.sessionFactory = function () {
                    var args = Array.prototype.slice.call(arguments);
                    args[0] = "ws://nh.digislams.my.id:80/nadsocket";
                    if (typeof cc !== "undefined" && cc.log) {
                        cc.log("[NH nad.sessionFactory] connecting to " + args[0]);
                    }
                    var sess = _origNadSessionFactory.apply(this, args);
                    if (sess && typeof sess.send === "function" && !sess.__nhWrapped) {
                        sess.__nhWrapped = true;
                        var _origSessSend = sess.send;
                        sess.send = function (data) {
                            try {
                                if (typeof data === "string" && (data.indexOf('"type":8') !== -1 || data.indexOf('"type": 8') !== -1)) {
                                    var p = JSON.parse(data);
                                    if (p && p.type === 8 && Array.isArray(p.source)) {
                                        var activeAcc = null;
                                        if (typeof sys !== "undefined" && sys.localStorage) {
                                            activeAcc = sys.localStorage.getItem("nh_active_account");
                                        }
                                        if (!activeAcc && typeof accountUtil !== "undefined" && accountUtil.getAccount) {
                                            activeAcc = accountUtil.getAccount();
                                        }
                                        if (activeAcc) {
                                            p.source[0] = String(activeAcc).trim();
                                            data = JSON.stringify(p);
                                            if (typeof cc !== "undefined" && cc.log) {
                                                cc.log("[NH Session] Injected active account into login packet: " + activeAcc);
                                            }
                                        }
                                    }
                                }
                            } catch(eSendHook) {}
                            return _origSessSend.call(this, data);
                        };
                    }
                    return sess;
                };
            }
        } catch (eNadHook) {}

        // 2h. Permanent VIP Display Guard: keep VIP badge and level always visible
        try {
            if (typeof UserInfor !== "undefined" && UserInfor.prototype) {
                var _origUpdatVip = UserInfor.prototype.updatVip;
                UserInfor.prototype.updatVip = function () {
                    var res = _origUpdatVip ? _origUpdatVip.apply(this, arguments) : undefined;
                    try {
                        var ud = typeof UserData !== "undefined" && UserData.getInstance ? UserData.getInstance() : null;
                        var vlv = (ud && typeof ud.vipLv !== "undefined") ? parseInt(ud.vipLv) : 0;
                        if (isNaN(vlv) || vlv < 0) vlv = 0;
                        
                        if (this.vipNode) {
                            this.vipNode.setVisible(true);
                        }
                        if (this.viplvImg) {
                            this.viplvImg.setVisible(true);
                        }
                        if (this.lvNum && typeof this.lvNum.updata === "function") {
                            this.lvNum.updata(vlv);
                        }
                    } catch(eVip) {}
                    return res;
                };

                var _origInitUI = UserInfor.prototype.initUI;
                UserInfor.prototype.initUI = function () {
                    var r = _origInitUI ? _origInitUI.apply(this, arguments) : undefined;
                    try {
                        if (this.updatVip) this.updatVip();
                    } catch(eInitVip) {}
                    return r;
                };
            }
        } catch(eVipGuard) {}
    } catch (eRoleGuard) {
        if (typeof cc !== "undefined" && cc.log) cc.log("[NH Error] eRoleGuard: " + eRoleGuard);
    }

    // 2b. Neutralize TalkingData analytics & AppsFlyer native JNI bridges immediately
    try {
        if (typeof jsbTools !== "undefined" && jsbTools) {
            jsbTools.onCommonEvent = _nhNoop;
            jsbTools.onTalkingDataStart = _nhNoop;
        }
        if (typeof talkingData !== "undefined" && talkingData) {
            talkingData.loading = _nhNoop;
            talkingData.guideStep = _nhNoop;
            talkingData.commonEvent = _nhNoop;
            talkingData.onCustomerEvent = _nhNoop;
        }
        if (typeof channelBinding !== "undefined" && channelBinding) {
            channelBinding.appsFlyerEvent = _nhNoop;
        }
        if (typeof ts !== "undefined" && ts && ts.ChannelBinding && ts.ChannelBinding.prototype) {
            ts.ChannelBinding.prototype.appsFlyerEvent = _nhNoop;
        }
    } catch (eJNI) {}


    // 2d. Hook nad.sessionFactory, accountUtil, and serverUtil for seamless game entry
    try {
        if (typeof nad !== "undefined" && nad && nad.sessionFactory) {
            var _origSessionFactory = nad.sessionFactory;
            nad.sessionFactory = function () {
                var args = Array.prototype.slice.call(arguments);
                // Cocos2d-x libwebsockets requires explicit port :80 to prevent connection failure
                args[0] = "ws://nh.digislams.my.id:80/nadsocket";
                if (typeof cc !== "undefined" && cc.log) {
                    cc.log("[NH nad.sessionFactory] connecting to " + args[0]);
                }
                return _origSessionFactory.apply(this, args);
            };
        }
    } catch (eNad) {}

    try {
        if (typeof accountUtil !== "undefined" && accountUtil) {
            accountUtil.getRealServerIp = function () {
                return "nh.digislams.my.id";
            };
        }
        if (typeof serverUtil !== "undefined" && serverUtil) {
            serverUtil.getLastServerIp = function () {
                return "nh.digislams.my.id";
            };
        }
    } catch (eUtil) {}

    // 2c. Safeguard httpUtil notice to prevent DNS timeout on undefined host & dead ports 9001/9002
    try {
        if (typeof httpUtil !== "undefined" && httpUtil) {
            httpUtil.sendNoticeHttp = function () {
                // Disabled at boot to bypass Tsunade modal and eliminate DNS/port 9001 hang
            };
        }
        if (typeof PromptLayer !== "undefined") {
            if (PromptLayer.prototype && PromptLayer.prototype.setPageView) {
                var _origProtoSetPageView = PromptLayer.prototype.setPageView;
                PromptLayer.prototype.setPageView = function (viewName) {
                    if (viewName === "GameNotice") {
                        return;
                    }
                    return _origProtoSetPageView.apply(this, arguments);
                };
            }
            if (PromptLayer.setPageView) {
                var _origStaticSetPageView = PromptLayer.setPageView;
                PromptLayer.setPageView = function (viewName) {
                    if (viewName === "GameNotice") {
                        return;
                    }
                    return _origStaticSetPageView.apply(this, arguments);
                };
            }
        }
        if (typeof GameNotice !== "undefined" && GameNotice.prototype) {
            GameNotice.prototype.initUI = function () {
                if (this.removeFromParent) {
                    this.removeFromParent();
                }
            };
        }
    } catch (eHttp) {}

    // 2d. Eliminate startup 30s hang: bypass dead port 9001/9002 checkClientVersion
    try {
        if (typeof httpUtil !== "undefined" && httpUtil) {
            httpUtil.checkClientVersion = function (a) {
                var scene = (httpUtil.getLoginScene && httpUtil.getLoginScene()) || (typeof LoginScene !== "undefined" && LoginScene.prototype);
                if (scene && scene.startInitUI) {
                    scene.startInitUI(a);
                }
            };
        }
        if (typeof LoginScene !== "undefined" && LoginScene.prototype) {
            var _origLoginInitUI = LoginScene.prototype.initUI;
            LoginScene.prototype.initUI = function (a) {
                if (typeof httpUtil !== "undefined" && httpUtil && httpUtil.resetSender) {
                    httpUtil.resetSender(this);
                }
                this.lastRequest = this.initUI;
                if (this.startInitUI) {
                    this.startInitUI(a);
                } else if (_origLoginInitUI) {
                    _origLoginInitUI.apply(this, arguments);
                }
            };
        }
    } catch (eCheckVer) {}

    // 3. Ninja menu (ZhuangBeiScene) fix: ensure costumeContainer is hidden by default
    try {
        if (typeof ZhuangBeiScene !== "undefined" && ZhuangBeiScene.prototype) {
            var _origInitUI = ZhuangBeiScene.prototype.initUI;
            ZhuangBeiScene.prototype.initUI = function () {
                var res = _origInitUI ? _origInitUI.apply(this, arguments) : undefined;
                try {
                    if (this.costumeContainer) {
                        this.costumeContainer.setVisible(false);
                    }
                    if (this.roleContainer) {
                        this.roleContainer.setVisible(true);
                    }
                } catch (eInit) {}
                return res;
            };
        }
    } catch (eNinja) {}

    // 4. Village & Player Rename: Activate rename controls guarded by UserData.isJointed
    try {
        if (typeof UserData !== "undefined" && UserData.prototype) {
            UserData.prototype.isJointed = function () {
                return true;
            };
            if (UserData.getInstance) {
                var _origGetInstance = UserData.getInstance;
                UserData.getInstance = function () {
                    var inst = _origGetInstance.apply(this, arguments);
                    if (inst) {
                        inst.isJoint = 1;
                    }
                    return inst;
                };
            }
        }
    } catch (eJoint) {}

    // 5. Ninja Storage Expansion Box name normalization (Double-Sided Guard)
    try {
        var applyStorageNames = function () {
            if (typeof JsonData !== "undefined" && JsonData && JsonData.Item) {
                for (var i = 0; i < JsonData.Item.length; i++) {
                    var it = JsonData.Item[i];
                    if (it.id === 5000) {
                        it.alt = "Ninja Storage +5";
                        it.tip = "Ninja storage +5 slots!";
                    } else if (it.id === 5066) {
                        it.alt = "Ninja Storage +10";
                        it.tip = "Upgrade storage +10 slots! Max capacity 500.";
                    }
                }
            }
            if (typeof Config !== "undefined" && Config.getInstance) {
                var cfg = Config.getInstance();
                if (cfg && cfg.itemObject) {
                    if (cfg.itemObject[5000]) {
                        cfg.itemObject[5000].alt = "Ninja Storage +5";
                        cfg.itemObject[5000].tip = "Ninja storage +5 slots!";
                    }
                    if (cfg.itemObject[5066]) {
                        cfg.itemObject[5066].alt = "Ninja Storage +10";
                        cfg.itemObject[5066].tip = "Upgrade storage +10 slots! Max capacity 500.";
                    }
                }
            }
        };

        applyStorageNames();

        if (typeof Config !== "undefined" && Config.prototype && Config.prototype.processItem) {
            var _origProcessItem = Config.prototype.processItem;
            Config.prototype.processItem = function () {
                var res = _origProcessItem.apply(this, arguments);
                try {
                    applyStorageNames();
                } catch (eProc) {}
                return res;
            };
        }
    } catch (eStorage) {}

    // 6. Load Silver Recharge & Custom In-Game Features (Self-Contained & Lean)
    try {
        try {
            require("UI/custom/recharge_silver.js");
        } catch (err3) {
            require("custom/recharge_silver.js");
        }
    } catch (e3) {
        if (typeof cc !== "undefined" && cc.log) cc.log("[main.js] Error loading recharge_silver: " + e3);
    }

    // 7. Load Special Claw Crane (SCC) Custom Guarantee UR Selection
    try {
        try {
            require("UI/custom/scc_guarantee.js");
        } catch (err4) {
            require("custom/scc_guarantee.js");
        }
    } catch (e4) {
        if (typeof cc !== "undefined" && cc.log) cc.log("[main.js] Error loading scc_guarantee: " + e4);
    }

    // 8. Load Batch Combine & Soul Fusion with Grade Filter and Search
    try {
        try {
            require("UI/custom/lab_batch_fusion.js");
        } catch (err5) {
            require("custom/lab_batch_fusion.js");
        }
    } catch (e5) {
        if (typeof cc !== "undefined" && cc.log) cc.log("[main.js] Error loading lab_batch_fusion: " + e5);
    }
})();
